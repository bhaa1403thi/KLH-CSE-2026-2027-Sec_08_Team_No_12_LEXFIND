LEXFIND - EXPO-READY DSA-3 LEGAL DOCUMENT REPOSITORY
====================================================

OVERVIEW
--------
LEXFIND is a Java console application for searching and exploring a local corpus
of fictional educational legal records. It demonstrates DSA-3 algorithms through
working search features, an interactive repository browser, analytics charts, and
an offline multi-agent assistant hub.

WHAT IS INCLUDED
----------------
1. Smart Search: a live offline typing-suggestion dialog, exact KMP matching, KMP/Z/Rabin-Karp timing, automatic fuzzy fallback.
2. Fuzzy Search: typo-tolerant matching using Damerau-Levenshtein distance.
3. Multi-Keyword Search: Aho-Corasick pattern matching.
4. Find Similar Documents: suffix array / LCP longest-common-substring comparison.
5. Document Details: inspect a selected record.
6. Add New Document: add a record for the current session.
7. Repository Browser: sorting by ID, title, date, category, status or year; pagination;
   configurable page size; open any selected record.
8. Algorithm Reference: DSA-3 algorithm map, purposes and complexity notes.
9. Analytics Dashboard: Java Swing pie charts by category, status, and year, plus KPI cards.
10. Offline Smart Typing Assistant: live word/phrase suggestions sourced from local titles, categories, keywords, and curated legal phrases.
11. Local AI Agent Hub:
    - Legal Research Agent: heuristic relevance ranking of corpus records.
    - Document Summary Agent: extractive summary from a selected record.
    - Case Classification Agent: explainable keyword-based category suggestion.
    - Legal Drafting Assistant: guided fictional draft builder with preview and persistent save.
    - Data Quality Agent: checks missing/generic fields and repeated case numbers.
    - Case Link Discovery Agent: detects possible cross-record ID/case-number references.
12. Project Guide and recommended expo demo sequence.

IMPORTANT AI SCOPE
------------------
The typing assistant and agent hub are intentionally offline and dependency-free. Its current agents use
transparent rules, text matching, and template-based drafting; they do NOT connect
to a generative LLM and should not be described as a trained AI model. They need no
API key or internet access. Classification, relevance scores, summaries, and possible
links are suggestions that need human review. Drafts are fictional educational
examples, not legal advice or court-ready documents.

DATA SAFETY
-----------
The existing 50 corpus records are included and were not rewritten by this upgrade.
The drafting assistant validates IDs and uses CREATE_NEW semantics, so it will not
overwrite an existing corpus file. New drafts are saved to the same corpus directory
used at launch and become searchable immediately and after restarting the program.
Keep your own backup before making any future manual corpus edits.

REQUIREMENTS
------------
JDK 17 or later. The analytics dashboard needs a desktop environment that supports
Java Swing; all console features can run in a normal terminal.

RUN ON WINDOWS POWERSHELL
-------------------------
1. Extract this ZIP.
2. Open the TEXT_HACK_DSA3_JAVA folder in VS Code.
3. Open Terminal > New Terminal.
4. Run:
   javac -encoding UTF-8 -d out (Get-ChildItem -Recurse src -Filter *.java).FullName
   java -cp out texthack.app.TextHackApp

Or double-click/run run.bat from the project folder.

RUN ON LINUX / macOS
--------------------
   mkdir -p out
   javac -encoding UTF-8 -d out $(find src -name "*.java")
   java -cp out texthack.app.TextHackApp

EXPO DEMO FLOW (ABOUT 4-6 MINUTES)
---------------------------------
1. Choose 1 and type slowly (for example, "contr") to demonstrate live suggestions, then search for: property
2. Choose 1 again and try a misspelling such as: proprty
3. Choose 3 and enter: property, evidence
4. Choose 4, enter a document ID such as D1, and show similar-document scores.
5. Choose 7, sort by title or newest date, move pages, and open a record.
6. Choose 9 to show category/status/year pie charts.
7. Choose 10 > 1 and research: property ownership dispute.
8. Choose 10 > 3 and classify a short fictional case description.
9. Optionally demonstrate the draft assistant using a NEW ID that is not already used.

DSA-3 ALGORITHM COVERAGE
------------------------
String matching: Naive, KMP/LPS, Z, Rabin-Karp, Aho-Corasick.
Fuzzy/sequence DP: Levenshtein, Damerau-Levenshtein, weighted edit distance,
Needleman-Wunsch, Smith-Waterman.
Suffix structures: prefix-doubling suffix array, Kasai LCP, longest common substring.
Advanced DP: matrix-chain multiplication, bitmask TSP, Hamiltonian path, SOS DP, tree subset DP.
Graph/flow: Ford-Fulkerson, Edmonds-Karp, Dinic, bipartite matching, project selection.
Approximation: Vertex Cover 2-approximation, Greedy Set Cover, Subset Sum, 0/1 Knapsack.
Randomized: Miller-Rabin, randomized Quicksort, reservoir sampling, universal hashing.
Parallel: work, parallel reduction, prefix scan, Brent upper-bound calculator.

ACADEMIC LIMITATIONS
--------------------
- The corpus is fictional and local; it is not an official court database or a live Wikipedia mirror.
- The suffix-array implementation uses prefix doubling; not every advanced syllabus concept
  (for example citation-flow ranking or scheduling) is integrated as a live project feature.
- Algorithm reference entries include engine demonstrations not all invoked by the menu.
- Timing results vary with JVM warm-up and machine load.
