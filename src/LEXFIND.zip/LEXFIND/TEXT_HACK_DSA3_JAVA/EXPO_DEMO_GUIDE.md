# LEXFIND Expo Demo Guide

## 30-second introduction
LEXFIND is a Java-based legal-document repository that demonstrates how data structures and algorithms make text search, fuzzy matching, similarity analysis, browsing, and analytics more useful. The records are fictional educational examples.

## Recommended live sequence
1. **Smart Search:** search `property` and show exact matches plus KMP/Z/Rabin-Karp timing.
2. **Typo tolerance:** search `proprty` to trigger the Damerau-Levenshtein fallback.
3. **Multi-keyword search:** enter `property, evidence` to show Aho-Corasick matching.
4. **Similarity:** compare `D1` and show longest-common-substring scores.
5. **Repository Browser:** sort by title or date, change page size, open a selected record.
6. **Analytics:** choose option 9 and show pie charts for category, status, and year.
7. **Agent Hub:** choose option 10, then Research Agent for `property ownership dispute`.
8. **Optional:** demonstrate classification, quality checks, or draft a new fictional record using a unique ID.

## Explaining the agents honestly
The current agents are offline, explainable workflows based on text matching, rules, and templates. They are useful as specialist assistants but are not connected to a generative LLM or trained legal model. They do not provide legal advice. The drafting assistant creates fictional educational drafts and saves only after explicit confirmation.

## Likely questions
**Why multiple algorithms?** Different algorithms suit different search tasks: KMP for exact pattern matching, Aho-Corasick for several patterns, edit distance for typos, and suffix-array/LCP logic for common-substring comparison.

**Are the records real?** No. They are fictional examples for academic demonstration.

**Does it overwrite records?** The existing corpus is loaded read-only during ordinary browsing. The draft assistant validates a unique ID and creates a new file without overwriting an existing file.

**Is the agent output legally authoritative?** No. Suggestions and summaries are for demonstration and must be checked by a human.
