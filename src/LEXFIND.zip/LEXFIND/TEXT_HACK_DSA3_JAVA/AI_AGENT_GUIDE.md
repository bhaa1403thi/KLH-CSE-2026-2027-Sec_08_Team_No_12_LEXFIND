# LEXFIND Local Agent Hub

The agent hub is an offline, explainable multi-agent workflow built into the Java application. It has no external service dependency and does not require an API key.

| Agent | Input | Output | Method |
|---|---|---|---|
| Legal Research Agent | Topic or query | Top related corpus records with scores | Keyword overlap with title/keyword boosts |
| Document Summary Agent | Document ID | Short extractive summary | Sentence extraction from the selected record |
| Case Classification Agent | Facts/title/keywords | Suggested category and rule-match indicator | Transparent keyword rules |
| Legal Drafting Assistant | Guided fields | Previewed fictional draft, optionally saved as a new corpus file | Template-based drafting and explicit save confirmation |
| Data Quality Agent | Current corpus | Possible missing fields and repeated case numbers | Metadata validation rules |
| Case Link Discovery Agent | Current corpus | Possible document-ID/case-number cross references | Text scanning across loaded records |

## Limits and responsible use

- These are local rule-based/heuristic agents, not trained machine-learning models or a generative LLM.
- Scores are relevance indicators, not calibrated probabilities.
- Summaries and categories may miss context. Users should inspect original records.
- Cross-record matches are potential references, not verified citations.
- The drafting assistant is for fictional educational examples. It does not provide legal advice.
- The draft assistant accepts only IDs containing letters, digits, underscores, or hyphens, rejects duplicates, previews before saving, and creates a new file without overwriting an existing one.
