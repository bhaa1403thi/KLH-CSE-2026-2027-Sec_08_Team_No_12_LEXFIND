package texthack.repository;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardOpenOption;
import java.util.ArrayList;
import java.util.List;
import texthack.engine.corpus.Corpus;
import texthack.engine.corpus.Corpus.Document;
import texthack.model.LegalDocument;

public final class DocumentRepository {
    private final List<LegalDocument> documents = new ArrayList<>();
    private Path corpusDirectory = Path.of("corpus");

    public void loadCorpus(String path) throws IOException {
        corpusDirectory = Path.of(path);
        Document[] source = new Corpus(path).load();
        for (Document document : source) {
            LegalDocument parsed = parse(document);
            if (parsed != null) documents.add(parsed);
        }
    }
    public List<LegalDocument> all() { return new ArrayList<>(documents); }
    public LegalDocument findById(String id) {
        for (LegalDocument document : documents) {
            if (document.getDocumentId().equalsIgnoreCase(id)) return document;
        }
        return null;
    }
    public boolean add(LegalDocument document) {
        if (findById(document.getDocumentId()) != null) return false;
        documents.add(document); return true;
    }

    /** Persists a newly created educational record without overwriting any existing corpus file. */
    public boolean addAndSave(LegalDocument document) throws IOException {
        if (findById(document.getDocumentId()) != null) return false;
        String id = document.getDocumentId();
        if (id == null || !id.matches("[A-Za-z0-9_-]+")) return false;
        Files.createDirectories(corpusDirectory);
        Path target = corpusDirectory.resolve(id + ".txt");
        if (Files.exists(target)) return false;
        String text = "Document ID: " + clean(document.getDocumentId()) + "\n"
                + "Case Number: " + clean(document.getCaseNumber()) + "\n"
                + "Title: " + clean(document.getTitle()) + "\n"
                + "Registration Date: " + clean(document.getRegistrationDate()) + "\n"
                + "Registration Time: " + clean(document.getRegistrationTime()) + "\n"
                + "Category: " + clean(document.getCategory()) + "\n"
                + "Year: " + document.getYear() + "\n"
                + "Plaintiff Name: " + clean(document.getPlaintiff()) + "\n"
                + "Defendant Name: " + clean(document.getDefendant()) + "\n"
                + "Document Type: " + clean(document.getDocumentType()) + "\n"
                + "Court Name: " + clean(document.getCourt()) + "\n"
                + "Case Status: " + clean(document.getStatus()) + "\n"
                + "Keywords: " + clean(document.getKeywords()) + "\n\n"
                + "Case Details:\n" + (document.getContent() == null ? "" : document.getContent()) + "\n";
        try {
            Files.writeString(target, text, StandardCharsets.UTF_8, StandardOpenOption.CREATE_NEW);
            if (!add(document)) { Files.deleteIfExists(target); return false; }
            return true;
        } catch (IOException ex) {
            Files.deleteIfExists(target);
            throw ex;
        }
    }

    private static String clean(String value) {
        return value == null ? "" : value.replace("\r", " ").replace("\n", " ").trim();
    }

    private LegalDocument parse(Document source) {
        String[] lines = source.text.split("\\r?\\n");
        String id = value(lines, "Document ID", source.name.replace(".txt", ""));
        String caseNumber = value(lines, "Case Number", "CASE-" + id);
        String title = value(lines, "Title", "Untitled Legal Document");
        String date = value(lines, "Registration Date", "01-01-2026");
        String time = value(lines, "Registration Time", "09:00 AM");
        String category = value(lines, "Category", "General");
        int year = number(value(lines, "Year", "2026"), 2026);
        String plaintiff = value(lines, "Plaintiff Name", value(lines, "Victim Name", "Fictional Plaintiff"));
        String defendant = value(lines, "Defendant Name", value(lines, "Opponent Name", "Fictional Defendant"));
        String court = value(lines, "Court Name", "District Legal Court");
        String status = value(lines, "Case Status", "Pending");
        String documentType = value(lines, "Document Type", title);
        String keywords = value(lines, "Keywords", inferKeywords(source.text, category, title));
        return new LegalDocument(id, caseNumber, title, date, time, category, year,
                plaintiff, defendant, documentType, court, status, keywords, source.text);
    }
    private static String value(String[] lines, String label, String fallback) {
        String prefix = label.toLowerCase() + ":";
        for (String line : lines) if (line.toLowerCase().startsWith(prefix))
            return line.substring(prefix.length()).trim();
        return fallback;
    }
    private static int number(String text, int fallback) {
        try { return Integer.parseInt(text.trim()); }
        catch (NumberFormatException exception) { return fallback; }
    }
    private static String inferKeywords(String text, String category, String title) {
        String lower = text.toLowerCase();
        String[] candidates = {"property", "ownership", "land", "contract", "theft",
                "evidence", "family", "employment", "cybercrime", "consumer",
                "copyright", "constitutional", "fraud", "criminal", "civil"};
        StringBuilder result = new StringBuilder(category).append(", ").append(title);
        for (String candidate : candidates)
            if (lower.contains(candidate) && result.indexOf(candidate) < 0)
                result.append(", ").append(candidate);
        return result.toString();
    }
}
