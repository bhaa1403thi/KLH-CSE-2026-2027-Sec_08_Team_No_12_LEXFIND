package texthack.model;

public final class LegalDocument {
    private final String documentId;
    private final String caseNumber;
    private final String title;
    private final String registrationDate;
    private final String registrationTime;
    private final String category;
    private final int year;
    private final String plaintiff;
    private final String defendant;
    private final String documentType;
    private final String court;
    private final String status;
    private final String keywords;
    private final String content;

    public LegalDocument(String documentId, String caseNumber, String title,
            String registrationDate, String registrationTime, String category,
            int year, String plaintiff, String defendant, String documentType,
            String court, String status, String keywords, String content) {
        this.documentId = documentId; this.caseNumber = caseNumber; this.title = title;
        this.registrationDate = registrationDate; this.registrationTime = registrationTime;
        this.category = category; this.year = year; this.plaintiff = plaintiff;
        this.defendant = defendant; this.documentType = documentType; this.court = court;
        this.status = status; this.keywords = keywords; this.content = content;
    }
    public String getDocumentId() { return documentId; }
    public String getCaseNumber() { return caseNumber; }
    public String getTitle() { return title; }
    public String getRegistrationDate() { return registrationDate; }
    public String getRegistrationTime() { return registrationTime; }
    public String getCategory() { return category; }
    public int getYear() { return year; }
    public String getPlaintiff() { return plaintiff; }
    public String getDefendant() { return defendant; }
    public String getDocumentType() { return documentType; }
    public String getCourt() { return court; }
    public String getStatus() { return status; }
    public String getKeywords() { return keywords; }
    public String getContent() { return content; }
    public String searchableText() {
        return (documentId + " " + caseNumber + " " + title + " " + category + " "
                + plaintiff + " " + defendant + " " + documentType + " " + court + " "
                + status + " " + keywords + " " + content).toLowerCase();
    }
}
