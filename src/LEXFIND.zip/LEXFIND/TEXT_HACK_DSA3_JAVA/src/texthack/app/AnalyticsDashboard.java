package texthack.app;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.RenderingHints;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import javax.swing.BorderFactory;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTabbedPane;
import javax.swing.SwingConstants;
import javax.swing.SwingUtilities;
import texthack.model.LegalDocument;

/** Lightweight, dependency-free Swing analytics dashboard for the current repository snapshot. */
public final class AnalyticsDashboard {
    private AnalyticsDashboard() {}

    public static void show(List<LegalDocument> documents, int searches, int added,
            Map<String, Integer> categories, Map<String, Integer> statuses,
            Map<String, Integer> years) {
        Runnable task = () -> createWindow(documents.size(), searches, added,
                categories, statuses, years);
        if (SwingUtilities.isEventDispatchThread()) task.run();
        else SwingUtilities.invokeLater(task);
    }

    private static void createWindow(int total, int searches, int added,
            Map<String, Integer> categories, Map<String, Integer> statuses,
            Map<String, Integer> years) {
        JFrame frame = new JFrame("LEXFIND | Analytics & Statistics");
        frame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        frame.setSize(1120, 760);
        frame.setMinimumSize(new Dimension(900, 620));
        frame.setLocationRelativeTo(null);
        frame.setLayout(new BorderLayout(14, 14));

        JPanel root = new JPanel(new BorderLayout(12, 12));
        root.setBackground(new Color(246, 248, 252));
        root.setBorder(BorderFactory.createEmptyBorder(18, 18, 18, 18));

        JLabel heading = new JLabel("LEXFIND ANALYTICS DASHBOARD", SwingConstants.CENTER);
        heading.setFont(new Font("SansSerif", Font.BOLD, 25));
        heading.setForeground(new Color(29, 47, 79));
        root.add(heading, BorderLayout.NORTH);

        JPanel content = new JPanel(new BorderLayout(10, 10));
        content.setOpaque(false);
        JPanel cards = new JPanel(new java.awt.GridLayout(1, 3, 12, 12));
        cards.setOpaque(false);
        cards.add(summaryCard("TOTAL DOCUMENTS", String.valueOf(total)));
        cards.add(summaryCard("SEARCHES THIS SESSION", String.valueOf(searches)));
        cards.add(summaryCard("DOCUMENTS ADDED THIS SESSION", String.valueOf(added)));

        JTabbedPane tabs = new JTabbedPane();
        tabs.setFont(new Font("SansSerif", Font.BOLD, 13));
        tabs.addTab("By Category", new PieChartPanel("Document Distribution by Category", categories));
        tabs.addTab("By Case Status", new PieChartPanel("Case Status Distribution", statuses));
        tabs.addTab("By Year", new PieChartPanel("Document Distribution by Year", years));
        content.add(cards, BorderLayout.NORTH);
        content.add(tabs, BorderLayout.CENTER);
        root.add(content, BorderLayout.CENTER);

        JLabel footer = new JLabel("Live snapshot of the loaded fictional corpus • Charts use repository data", SwingConstants.CENTER);
        footer.setFont(new Font("SansSerif", Font.PLAIN, 12));
        footer.setForeground(new Color(90, 101, 120));
        root.add(footer, BorderLayout.SOUTH);
        frame.setContentPane(root);
        frame.setVisible(true);
    }

    private static JPanel summaryCard(String title, String value) {
        JPanel card = new JPanel(new BorderLayout(6, 6));
        card.setBackground(Color.WHITE);
        card.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(new Color(222, 228, 238)),
                BorderFactory.createEmptyBorder(15, 10, 15, 10)));
        JLabel titleLabel = new JLabel(title, SwingConstants.CENTER);
        titleLabel.setFont(new Font("SansSerif", Font.BOLD, 11));
        titleLabel.setForeground(new Color(89, 102, 124));
        JLabel valueLabel = new JLabel(value, SwingConstants.CENTER);
        valueLabel.setFont(new Font("SansSerif", Font.BOLD, 30));
        valueLabel.setForeground(new Color(35, 91, 153));
        card.add(titleLabel, BorderLayout.NORTH);
        card.add(valueLabel, BorderLayout.CENTER);
        return card;
    }

    private static final class PieChartPanel extends JPanel {
        private final String title;
        private final Map<String, Integer> values;
        private final Color[] palette = {
            new Color(47, 111, 176), new Color(55, 153, 111), new Color(230, 126, 58),
            new Color(151, 91, 176), new Color(218, 81, 91), new Color(48, 166, 180),
            new Color(201, 168, 60), new Color(103, 119, 145), new Color(206, 112, 164)
        };

        PieChartPanel(String title, Map<String, Integer> values) {
            this.title = title;
            this.values = new LinkedHashMap<>(values);
            setBackground(Color.WHITE);
            setPreferredSize(new Dimension(700, 500));
            setBorder(BorderFactory.createEmptyBorder(12, 12, 12, 12));
        }

        @Override protected void paintComponent(Graphics graphics) {
            super.paintComponent(graphics);
            Graphics2D g = (Graphics2D) graphics.create();
            g.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
            g.setColor(new Color(29, 47, 79));
            g.setFont(new Font("SansSerif", Font.BOLD, 18));
            g.drawString(title, 22, 30);

            int total = values.values().stream().mapToInt(Integer::intValue).sum();
            if (total <= 0) {
                g.setFont(new Font("SansSerif", Font.PLAIN, 15));
                g.drawString("No data available", 30, 70);
                g.dispose();
                return;
            }

            int diameter = Math.min(300, Math.min(getWidth() - 70, getHeight() - 130));
            diameter = Math.max(150, diameter);
            int x = Math.max(20, (getWidth() - diameter) / 2 - 110);
            int y = 62;
            int startAngle = 0;
            int usedAngle = 0;
            int index = 0;
            int count = values.size();
            for (Map.Entry<String, Integer> entry : values.entrySet()) {
                index++;
                int angle = index == count ? 360 - usedAngle
                        : (int) Math.round(entry.getValue() * 360.0 / total);
                if (index < count) usedAngle += angle;
                g.setColor(palette[(index - 1) % palette.length]);
                g.fillArc(x, y, diameter, diameter, startAngle, angle);
                startAngle += angle;
            }

            int legendX = x + diameter + 28;
            int legendY = y + 8;
            int row = 0;
            g.setFont(new Font("SansSerif", Font.PLAIN, 12));
            for (Map.Entry<String, Integer> entry : values.entrySet()) {
                int colorIndex = row % palette.length;
                double pct = entry.getValue() * 100.0 / total;
                int yy = legendY + row * 27;
                g.setColor(palette[colorIndex]);
                g.fillRoundRect(legendX, yy, 14, 14, 4, 4);
                g.setColor(new Color(39, 49, 66));
                String label = String.format("%s: %d (%.1f%%)", entry.getKey(), entry.getValue(), pct);
                int maxWidth = Math.max(60, getWidth() - legendX - 20);
                java.awt.FontMetrics fm = g.getFontMetrics();
                while (label.length() > 5 && fm.stringWidth(label) > maxWidth) label = label.substring(0, label.length() - 2) + "…";
                g.drawString(label, legendX + 22, yy + 12);
                row++;
            }
            g.dispose();
        }
    }
}
