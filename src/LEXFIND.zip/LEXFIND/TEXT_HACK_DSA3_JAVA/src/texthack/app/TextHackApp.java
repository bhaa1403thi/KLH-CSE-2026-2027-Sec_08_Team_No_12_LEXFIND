package texthack.app;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.HashMap;
import java.util.Map;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Set;
import java.util.LinkedHashMap;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;
import texthack.engine.dp.AdvancedDP;
import texthack.engine.stringalg.AhoCorasick;
import texthack.engine.stringalg.StringAlgorithms;
import texthack.engine.stringalg.SuffixArray;
import texthack.model.LegalDocument;
import texthack.repository.DocumentRepository;

public final class TextHackApp {
    private static final BufferedReader IN = new BufferedReader(new InputStreamReader(System.in));
    private static final DocumentRepository REPOSITORY = new DocumentRepository();
    private static int searches;
    private static int added;

    private TextHackApp() {}

    public static void main(String[] args) throws Exception {
        REPOSITORY.loadCorpus(args.length > 0 ? args[0] : "corpus");
        System.out.println("\n==============================================");
        System.out.println(" LEXFIND - LEGAL DOCUMENT REPOSITORY");
        System.out.println("==============================================");
        System.out.println("Fictional documents loaded: " + REPOSITORY.all().size());
        while (true) {
            menu();
            String choice = IN.readLine();
            if (choice == null || "11".equals(choice)) break;
            try {
                switch (choice) {
                    case "1" -> exactSearch();
                    case "2" -> fuzzySearch();
                    case "3" -> multiKeywordSearch();
                    case "4" -> similarity();
                    case "5" -> details();
                    case "6" -> addDocument();
                    case "7" -> viewAll();
                    case "8" -> algorithmInfo();
                    case "9" -> statistics();
                    case "10" -> projectAbout();
                    default -> System.out.println("Please choose a number from 1 to 11.");
                }
            } catch (NumberFormatException exception) {
                System.out.println("Invalid number. Please try again.");
            } catch (IOException exception) {
                System.out.println("Input error: " + exception.getMessage());
            }
        }
        System.out.println("LEXFIND closed.");
    }

    private static void menu() {
        System.out.println("\n--- LEXFIND - LEGAL DOCUMENT REPOSITORY ---");
        System.out.println("1. Exact Case Search");
        System.out.println("2. Fuzzy Search (spelling-tolerant)");
        System.out.println("3. Multi-Keyword Search (table + pages)");
        System.out.println("4. Compare Similar Documents (scan + graph)");
        System.out.println("5. Document Details (summary / full record)");
        System.out.println("6. Add New Document");
        System.out.println("7. View All Documents");
        System.out.println("8. Algorithms, Complexity & CO Mapping");
        System.out.println("9. Analytics Dashboard");
        System.out.println("10. Project Guide & Expo Demo Flow");
        System.out.println("11. Exit");
        System.out.print("Select: ");
    }

    private static volatile boolean spinnerRunning;
    private static Thread spinnerThread;

    /** One search entry point: exact whole-term search first, fuzzy fallback if needed. */
    private static void exactSearch() throws IOException {
        banner("EXACT CASE SEARCH");
        String rawQuery = ask("Enter exact word or phrase");
        if (rawQuery.isBlank()) { System.out.println("Search term cannot be empty."); return; }
        String typeFilter = ask("Document type to search (enter ALL for every type)");
        if (typeFilter.isBlank()) typeFilter = "ALL";
        String query = rawQuery.toLowerCase().trim().replaceAll("\\s+", " ");
        List<LegalDocument> docs = filterByType(REPOSITORY.all(), typeFilter);
        if (docs.isEmpty()) { System.out.println("No documents match that document type."); return; }
        searches++;

        List<SearchRow> matches = new ArrayList<>();
        long kmpNanos = 0L, zNanos = 0L, rkNanos = 0L;
        startSpinner("Scanning document files and benchmarking exact-search algorithms");
        try {
            for (LegalDocument d : docs) {
                String text = d.searchableText();
                long before = System.nanoTime();
                int[] offsets = StringAlgorithms.kmpAll(text, query);
                kmpNanos += System.nanoTime() - before;
                List<Integer> positions = wholeTermPositions(text, offsets, query);
                if (!positions.isEmpty()) matches.add(new SearchRow(d, positions.size(),
                        matchingField(d, query), excerpt(text, positions.get(0), query)));
            }
            for (LegalDocument d : docs) {
                long before = System.nanoTime();
                StringAlgorithms.zSearch(d.searchableText(), query);
                zNanos += System.nanoTime() - before;
            }
            for (LegalDocument d : docs) {
                long before = System.nanoTime();
                StringAlgorithms.rabinKarp(d.searchableText(), query);
                rkNanos += System.nanoTime() - before;
            }
        } finally { stopSpinner(); }

        System.out.println("\nEXACT SEARCH REPORT");
        System.out.println("Query: \"" + rawQuery + "\" | Type filter: " + typeFilter);
        System.out.println("Files/documents scanned: " + docs.size());
        System.out.println("ALGORITHM RUNTIME (same query and same filtered corpus)");
        printTiming("KMP exact search", kmpNanos);
        printTiming("Z algorithm", zNanos);
        printTiming("Rabin-Karp", rkNanos);
        System.out.println("KMP supplies the exact result list; Z and Rabin-Karp are benchmarked automatically.");
        System.out.println("Timings vary with machine load, corpus size, and JVM warm-up.");
        if (matches.isEmpty()) {
            System.out.println("No exact whole-word/phrase match found. Use option 2 if you want spelling-tolerant search.");
            return;
        }
        System.out.printf("%n%-7s | %-24s | %-18s | %-5s | %s%n", "ID", "TITLE", "FIELD", "HITS", "MATCH PREVIEW");
        System.out.println("-".repeat(110));
        for (SearchRow row : matches) {
            System.out.printf("%-7s | %-24s | %-18s | %-5d | %s%n",
                    clip(row.document.getDocumentId(), 7), clip(row.document.getTitle(), 24),
                    clip(row.field, 18), row.count, clip(row.preview, 48));
        }
        System.out.println("\nExact matches found: " + matches.size());
    }

    private static List<Integer> wholeTermPositions(String text, int[] offsets, String query) {
        List<Integer> result = new ArrayList<>();
        for (int offset : offsets) {
            int end = offset + query.length();
            boolean leftBoundary = offset == 0 || !Character.isLetterOrDigit(text.charAt(offset - 1));
            boolean rightBoundary = end >= text.length() || !Character.isLetterOrDigit(text.charAt(end));
            if (leftBoundary && rightBoundary) result.add(offset);
        }
        return result;
    }

    private static String excerpt(String text, int position, String query) {
        int start = Math.max(0, position - 55);
        int end = Math.min(text.length(), position + query.length() + 75);
        String value = text.substring(start, end).replaceAll("\\s+", " ").trim();
        if (start > 0) value = "…" + value;
        if (end < text.length()) value += "…";
        // Highlight the searched term in terminals that support ANSI colors.
        value = value.replace(query, "\u001B[1;33m" + query + "\u001B[0m");
        return value;
    }

    private static void printTiming(String label, long nanos) {
        System.out.printf("  %-25s %10.3f ms%n", label, nanos / 1_000_000.0);
    }

    private static void startSpinner(String message) {
        spinnerRunning = true;
        spinnerThread = new Thread(() -> {
            char[] frames = {'|', '/', '-', '\\'};
            int index = 0;
            while (spinnerRunning) {
                System.out.print("\r" + frames[index++ % frames.length] + " " + message + "...");
                System.out.flush();
                try { Thread.sleep(100); }
                catch (InterruptedException exception) { Thread.currentThread().interrupt(); break; }
            }
        }, "lexfind-search-spinner");
        spinnerThread.setDaemon(true);
        spinnerThread.start();
    }

    private static void stopSpinner() {
        spinnerRunning = false;
        if (spinnerThread != null) {
            try { spinnerThread.join(250); }
            catch (InterruptedException exception) { Thread.currentThread().interrupt(); }
        }
        System.out.print("\r" + " ".repeat(100) + "\r");
        System.out.flush();
    }

    private static void banner(String title) {
        System.out.println("\n+----------------------------------------------------------+");
        System.out.printf("| %-56s |%n", title);
        System.out.println("+----------------------------------------------------------+");
    }

    private static String matchingField(LegalDocument d, String q) {
        String query = q.toLowerCase();
        if (d.getCaseNumber().toLowerCase().contains(query)) return "Case Number";
        if (d.getTitle().toLowerCase().contains(query)) return "Title";
        if (d.getKeywords().toLowerCase().contains(query)) return "Keywords";
        if (d.getCategory().toLowerCase().contains(query)) return "Category";
        return "Content or metadata";
    }
    private static String algorithmName(String value) {
        return value.equals("z") ? "Z Algorithm" : value.equals("rabin-karp") ? "Rabin-Karp" : "KMP";
    }

    private static void fuzzySearch() throws IOException {
        banner("FUZZY SEARCH");
        String query = ask("Enter one word (misspellings are allowed)").toLowerCase().trim();
        if (query.isBlank()) { System.out.println("Query cannot be empty."); return; }
        String typeFilter = ask("Document type to search (ALL for every type)");
        if (typeFilter.isBlank()) typeFilter = "ALL";
        List<LegalDocument> docs = filterByType(REPOSITORY.all(), typeFilter);
        if (docs.isEmpty()) { System.out.println("No documents match that document type."); return; }

        long started = System.nanoTime();
        List<FuzzyRow> rows = new ArrayList<>();
        int maxDistance = query.length() <= 4 ? 1 : Math.max(2, query.length() / 4);
        startSpinner("Checking words in document files with Damerau-Levenshtein distance");
        try {
            for (LegalDocument d : docs) {
                int best = Integer.MAX_VALUE;
                String bestWord = "";
                for (String word : words(d.searchableText())) {
                    if (word.length() < Math.max(1, query.length() - maxDistance)
                            || word.length() > query.length() + maxDistance) continue;
                    int distance = AdvancedDP.damerauLevenshtein(query, word);
                    if (distance < best) { best = distance; bestWord = word; }
                    if (best == 0) break;
                }
                if (best <= maxDistance)
                    rows.add(new FuzzyRow(d, bestWord, best));
            }
        } finally { stopSpinner(); }
        long elapsed = System.nanoTime() - started;
        rows.sort(Comparator.comparingInt((FuzzyRow r) -> r.distance)
                .thenComparing(r -> r.document.getDocumentId(), TextHackApp::compareDocumentIds));

        System.out.println("\nFUZZY SEARCH REPORT");
        System.out.println("Query: " + query + " | Type filter: " + typeFilter);
        System.out.println("Files/documents scanned: " + docs.size());
        printTiming("Damerau-Levenshtein", elapsed);
        System.out.println("Edit distance = minimum insertions, deletions, substitutions, or adjacent transpositions.");
        if (rows.isEmpty()) { System.out.println("No close spelling matches found. Try a shorter or more accurate word."); return; }
        System.out.printf("%n%-7s | %-26s | %-20s | %-8s | %s%n", "ID", "TITLE", "CLOSEST WORD", "DISTANCE", "TYPE");
        System.out.println("-".repeat(100));
        for (FuzzyRow r : rows) System.out.printf("%-7s | %-26s | %-20s | %-8d | %s%n",
                clip(r.document.getDocumentId(), 7), clip(r.document.getTitle(), 26),
                clip(r.word, 20), r.distance, clip(r.document.getDocumentType(), 20));
        System.out.println("Lower distance means a closer spelling match. These are suggestions, not legal conclusions.");
    }

    private static void multiKeywordSearch() throws IOException {
        banner("MULTI-KEYWORD SEARCH");
        String line = ask("Enter keywords separated by commas");
        String[] patterns = splitComma(line);
        if (patterns.length == 0) { System.out.println("Enter at least one keyword."); return; }
        String typeFilter = ask("Document type to search (ALL for every type)");
        if (typeFilter.isBlank()) typeFilter = "ALL";
        List<LegalDocument> docs = filterByType(REPOSITORY.all(), typeFilter);
        if (docs.isEmpty()) { System.out.println("No documents match that document type."); return; }

        int pageSize = parsePositiveOrDefault(ask("Rows per page (default 5)"), 5);
        int page = 0;
        List<KeywordRow> results = new ArrayList<>();
        long started = System.nanoTime();
        startSpinner("Scanning files for all supplied keywords");
        try {
            AhoCorasick matcher = new AhoCorasick(patterns);
            for (LegalDocument d : docs) {
                int[] counts = matcher.matchingCounts(d.searchableText());
                List<String> found = new ArrayList<>();
                int total = 0;
                for (int i = 0; i < counts.length; i++) if (counts[i] > 0) {
                    found.add(patterns[i] + " (" + counts[i] + ")");
                    total += counts[i];
                }
                if (total > 0) results.add(new KeywordRow(d, found, total));
            }
        } finally { stopSpinner(); }
        long elapsed = System.nanoTime() - started;
        results.sort(Comparator.comparingInt((KeywordRow r) -> r.total).reversed()
                .thenComparing(r -> r.document.getDocumentId(), TextHackApp::compareDocumentIds));
        System.out.println("\nFiles/documents scanned: " + docs.size());
        printTiming("Aho-Corasick multi-pattern search", elapsed);
        System.out.println("Algorithm scans the text once for the supplied set of keywords; more hits appear first.");
        if (results.isEmpty()) { System.out.println("No documents matched any supplied keyword."); return; }

        while (true) {
            int pages = (results.size() + pageSize - 1) / pageSize;
            page = Math.max(0, Math.min(page, pages - 1));
            int from = page * pageSize, to = Math.min(from + pageSize, results.size());
            System.out.printf("%nMULTI-KEYWORD RESULTS - page %d/%d | %d total result(s)%n", page + 1, pages, results.size());
            System.out.printf("%-7s | %-27s | %-18s | %-6s | %s%n", "ID", "TITLE", "TYPE", "HITS", "MATCHED KEYWORDS");
            System.out.println("-".repeat(112));
            for (int i = from; i < to; i++) {
                KeywordRow r = results.get(i);
                System.out.printf("%-7s | %-27s | %-18s | %-6d | %s%n",
                        clip(r.document.getDocumentId(), 7), clip(r.document.getTitle(), 27),
                        clip(r.document.getDocumentType(), 18), r.total, clip(String.join(", ", r.keywords), 44));
            }
            if (pages <= 1) break;
            String action = ask("Enter N for next page, P for previous, number to open details, or Q to quit pages");
            if (action.equalsIgnoreCase("N")) { if (page + 1 < pages) page++; else System.out.println("Already on last page."); }
            else if (action.equalsIgnoreCase("P")) { if (page > 0) page--; else System.out.println("Already on first page."); }
            else if (action.equalsIgnoreCase("Q")) break;
            else {
                try {
                    int row = Integer.parseInt(action) - 1;
                    if (row >= from && row < to) showBrief(results.get(row).document);
                    else System.out.println("Enter a displayed row number (" + (from + 1) + "-" + to + ").");
                } catch (NumberFormatException ex) { System.out.println("Choose N, P, Q, or a displayed row number."); }
            }
        }
    }

    private static void similarity() throws IOException {
        banner("SIMILAR DOCUMENT COMPARISON");
        LegalDocument source = REPOSITORY.findById(ask("Enter the source document ID"));
        if (source == null) { System.out.println("Document not found."); return; }
        int count = parsePositiveOrDefault(ask("How many other documents do you want to scan? (max " + Math.max(0, REPOSITORY.all().size() - 1) + ")"), 5);
        String typeFilter = ask("Document type/category to compare (ALL for every type)");
        List<LegalDocument> available = filterByType(REPOSITORY.all(), typeFilter);
        available.removeIf(d -> d.getDocumentId().equalsIgnoreCase(source.getDocumentId()));
        available.sort((a, b) -> compareDocumentIds(a.getDocumentId(), b.getDocumentId()));
        if (available.isEmpty()) { System.out.println("No documents available for that type filter."); return; }
        count = Math.min(count, available.size());
        System.out.println("\nAvailable documents:");
        for (LegalDocument d : available)
            System.out.println("  " + d.getDocumentId() + " — " + d.getTitle());
        String idsText = ask("Enter " + count + " document IDs separated by commas (or ALL to scan the first " + count + ")");
        List<LegalDocument> chosen = new ArrayList<>();
        if (idsText.equalsIgnoreCase("ALL")) chosen.addAll(available.subList(0, count));
        else {
            for (String id : splitComma(idsText)) {
                LegalDocument d = REPOSITORY.findById(id);
                if (d != null && !d.getDocumentId().equalsIgnoreCase(source.getDocumentId())
                        && chosen.size() < count
                        && chosen.stream().noneMatch(x -> x.getDocumentId().equalsIgnoreCase(d.getDocumentId()))) chosen.add(d);
            }
        }
        if (chosen.isEmpty()) { System.out.println("No valid comparison documents selected."); return; }

        List<SimilarityRow> rows = new ArrayList<>();
        long started = System.nanoTime();
        startSpinner("Scanning selected documents and calculating similarity");
        try {
            Set<String> sourceWords = tokenSet(source.getContent());
            for (LegalDocument d : chosen) {
                Set<String> otherWords = tokenSet(d.getContent());
                Set<String> intersection = new java.util.HashSet<>(sourceWords);
                intersection.retainAll(otherWords);
                Set<String> union = new java.util.HashSet<>(sourceWords);
                union.addAll(otherWords);
                double score = union.isEmpty() ? 0.0 : 100.0 * intersection.size() / union.size();
                rows.add(new SimilarityRow(d, score, intersection.size(), union.size()));
            }
        } finally { stopSpinner(); }
        long elapsed = System.nanoTime() - started;
        rows.sort(Comparator.comparingDouble((SimilarityRow r) -> r.score).reversed()
                .thenComparing(r -> r.document.getDocumentId(), TextHackApp::compareDocumentIds));

        System.out.println("\nSIMILARITY REPORT");
        System.out.println("Source: " + source.getDocumentId() + " — " + source.getTitle());
        System.out.println("Documents compared: " + chosen.size());
        printTiming("Word-set Jaccard similarity", elapsed);
        System.out.println("\nGRAPH (each # represents about 2% similarity)");
        for (SimilarityRow r : rows) {
            int bars = (int) Math.round(r.score / 2.0);
            System.out.printf("%-6s %-30s | %-50s %5.1f%%%n",
                    r.document.getDocumentId(), clip(r.document.getTitle(), 30), "#".repeat(Math.max(0, bars)), r.score);
        }
        System.out.println("\nHOW TO READ THE PERCENTAGE:");
        System.out.println("Similarity % = 100 × shared unique words ÷ all unique words across both documents.");
        System.out.println("Example: 20 shared words out of 100 unique words in the combined set = 20%.");
        System.out.println("This measures vocabulary overlap, not legal correctness or whether two cases have the same outcome.");
    }

    private static void details() throws IOException {
        banner("DOCUMENT DETAILS");
        LegalDocument d = REPOSITORY.findById(ask("Enter document ID"));
        if (d == null) { System.out.println("Document not found."); return; }
        showBrief(d);
        String more = ask("Type FULL to view the full document, or press Enter for summary");
        if (more.equalsIgnoreCase("FULL")) {
            System.out.println("\n================ FULL DOCUMENT ================");
            System.out.println("Document ID: " + d.getDocumentId());
            System.out.println("Case Number: " + d.getCaseNumber());
            System.out.println("Title: " + d.getTitle());
            System.out.println("Registration: " + d.getRegistrationDate() + " " + d.getRegistrationTime());
            System.out.println("Category: " + d.getCategory() + " | Year: " + d.getYear());
            System.out.println("Plaintiff: " + d.getPlaintiff() + " | Defendant: " + d.getDefendant());
            System.out.println("Document Type: " + d.getDocumentType() + " | Court: " + d.getCourt());
            System.out.println("Status: " + d.getStatus() + "\nKeywords: " + d.getKeywords());
            System.out.println("\nFull file content:\n" + d.getContent());
        }
    }

    private static void showBrief(LegalDocument d) {
        System.out.println("\n+-------------------- CASE SUMMARY --------------------+");
        System.out.println("ID / Case No. : " + d.getDocumentId() + " / " + d.getCaseNumber());
        System.out.println("Title         : " + d.getTitle());
        System.out.println("Type / Category: " + d.getDocumentType() + " / " + d.getCategory());
        System.out.println("Year / Status : " + d.getYear() + " / " + d.getStatus());
        System.out.println("Court         : " + d.getCourt());
        System.out.println("Parties       : " + d.getPlaintiff() + " vs " + d.getDefendant());
        System.out.println("Keywords      : " + d.getKeywords());
        System.out.println("Summary       : " + clip(d.getContent().replaceAll("\\s+", " ").trim(), 240));
        System.out.println("+-------------------------------------------------------+");
    }

    private static void addDocument() throws IOException {
        String id = ask("Document ID");
        if (id.length() == 0 || REPOSITORY.findById(id) != null) { System.out.println("ID is empty or already exists."); return; }
        String caseNumber = ask("Case number"), title = ask("Title"), category = ask("Category");
        String yearText = ask("Year");
        int year;
        try { year = Integer.parseInt(yearText); } catch (NumberFormatException exception) { System.out.println("Year must be numeric."); return; }
        if (year < 1900 || year > 2100 || title.length() == 0 || category.length() == 0) { System.out.println("Invalid year or empty required field."); return; }
        LegalDocument document = new LegalDocument(id, caseNumber, title, ask("Registration date"), ask("Registration time"),
                category, year, ask("Plaintiff"), ask("Defendant"), ask("Document type"), ask("Court"),
                ask("Case status"), ask("Keywords"), ask("Content"));
        REPOSITORY.add(document); added++;
        System.out.println("Document added successfully.");
    }

    private static void viewAll() throws IOException {
        List<LegalDocument> documents = new ArrayList<>(REPOSITORY.all());
        if (documents.isEmpty()) {
            System.out.println("No documents available in the repository.");
            return;
        }
        int pageSize = 10;
        int page = 0;
        Comparator<LegalDocument> currentSort = Comparator.comparing(
                LegalDocument::getDocumentId, String.CASE_INSENSITIVE_ORDER);
        while (true) {
            documents.sort(currentSort);
            int totalPages = Math.max(1, (documents.size() + pageSize - 1) / pageSize);
            page = Math.max(0, Math.min(page, totalPages - 1));
            int start = page * pageSize;
            int end = Math.min(start + pageSize, documents.size());
            banner("REPOSITORY BROWSER | " + documents.size() + " DOCUMENTS");
            System.out.printf("%-5s %-9s %-26s %-14s %-12s %-16s%n",
                    "No.", "ID", "TITLE", "CATEGORY", "YEAR", "STATUS");
            System.out.println("-".repeat(92));
            for (int i = start; i < end; i++) {
                LegalDocument d = documents.get(i);
                System.out.printf("%-5d %-9s %-26.26s %-14.14s %-12d %-16.16s%n",
                        i + 1, d.getDocumentId(), d.getTitle(), d.getCategory(),
                        d.getYear(), d.getStatus());
            }
            System.out.println("-".repeat(92));
            System.out.printf("Page %d/%d | Showing %d-%d of %d%n", page + 1,
                    totalPages, start + 1, end, documents.size());
            System.out.println("1. Next page  2. Previous page  3. Open document by list number");
            System.out.println("4. Sort options  5. Change page size  6. Back to main menu");
            String action = ask("Choose action");
            switch (action) {
                case "1" -> { if (page + 1 < totalPages) page++; else System.out.println("Already on last page."); }
                case "2" -> { if (page > 0) page--; else System.out.println("Already on first page."); }
                case "3" -> {
                    try {
                        int number = Integer.parseInt(ask("Enter list number"));
                        if (number < start + 1 || number > end) System.out.println("Choose a number from the current page.");
                        else showDocument(documents.get(number - 1));
                    } catch (NumberFormatException e) { System.out.println("Enter a valid number."); }
                }
                case "4" -> {
                    System.out.println("Sort by: 1 ID A-Z | 2 Title A-Z | 3 Newest date | 4 Oldest date");
                    System.out.println("          5 Category A-Z | 6 Status A-Z | 7 Year newest first");
                    switch (ask("Sort choice")) {
                        case "1" -> currentSort = Comparator.comparing(LegalDocument::getDocumentId, String.CASE_INSENSITIVE_ORDER);
                        case "2" -> currentSort = Comparator.comparing(LegalDocument::getTitle, String.CASE_INSENSITIVE_ORDER);
                        case "3" -> currentSort = Comparator.comparing((LegalDocument d) -> parseDate(d.getRegistrationDate())).reversed();
                        case "4" -> currentSort = Comparator.comparing(d -> parseDate(d.getRegistrationDate()));
                        case "5" -> currentSort = Comparator.comparing(LegalDocument::getCategory, String.CASE_INSENSITIVE_ORDER);
                        case "6" -> currentSort = Comparator.comparing(LegalDocument::getStatus, String.CASE_INSENSITIVE_ORDER);
                        case "7" -> currentSort = Comparator.comparingInt(LegalDocument::getYear).reversed();
                        default -> System.out.println("Invalid sort choice.");
                    }
                    page = 0;
                }
                case "5" -> {
                    System.out.println("1. 10 documents  2. 20 documents  3. 50 documents  4. All documents");
                    switch (ask("Page size")) {
                        case "1" -> pageSize = 10;
                        case "2" -> pageSize = 20;
                        case "3" -> pageSize = 50;
                        case "4" -> pageSize = Math.max(1, documents.size());
                        default -> System.out.println("Invalid page size.");
                    }
                    page = 0;
                }
                case "6" -> { return; }
                default -> System.out.println("Invalid action.");
            }
            documents = new ArrayList<>(REPOSITORY.all());
        }
    }

    private static LocalDate parseDate(String value) {
        try { return LocalDate.parse(value, DateTimeFormatter.ofPattern("dd-MM-yyyy")); }
        catch (DateTimeParseException | NullPointerException e) { return LocalDate.MIN; }
    }

    private static void showDocument(LegalDocument d) {
        banner("DOCUMENT DETAILS | " + d.getDocumentId());
        System.out.println("Case Number     : " + d.getCaseNumber());
        System.out.println("Title           : " + d.getTitle());
        System.out.println("Registered      : " + d.getRegistrationDate() + " " + d.getRegistrationTime());
        System.out.println("Category / Year : " + d.getCategory() + " / " + d.getYear());
        System.out.println("Plaintiff       : " + d.getPlaintiff());
        System.out.println("Defendant       : " + d.getDefendant());
        System.out.println("Document Type   : " + d.getDocumentType());
        System.out.println("Court           : " + d.getCourt());
        System.out.println("Status          : " + d.getStatus());
        System.out.println("Keywords        : " + d.getKeywords());
        System.out.println("\nDOCUMENT CONTENT\n" + "-".repeat(70));
        System.out.println(d.getContent());
        System.out.println("-".repeat(70));
    }

    private static void algorithmInfo() {
        banner("ALGORITHMS, COMPLEXITY & COURSE OUTCOMES (COs)");
        System.out.println("LEXFIND uses the following algorithms in live features:");
        System.out.println("1. KMP exact string matching        | O(n + m) | CO: String processing / pattern matching");
        System.out.println("2. Damerau-Levenshtein distance    | O(mn)    | CO: Dynamic programming / approximate matching");
        System.out.println("3. Aho-Corasick multi-keyword scan | O(n + z) after trie build | CO: Multiple-pattern string matching");
        System.out.println("4. Word-set Jaccard similarity     | O(a + b) average with hash sets | CO: Similarity / set processing");
        System.out.println("5. Numeric document-ID ordering     | O(r log r) | CO: Sorting and comparator design");
        System.out.println("6. Repository filtering/pagination | O(N) filter, O(R log R) when sorting | CO: Data structures and searching");
        System.out.println("\nDSA3 TOPIC MAPPING (topic shown for curriculum discussion does not mean it is a live menu feature):");
        System.out.println("- Exact / pattern search -> KMP, Z algorithm, Rabin-Karp");
        System.out.println("- Fuzzy spelling search -> Dynamic programming, Damerau-Levenshtein");
        System.out.println("- Multi-keyword search -> Trie and Aho-Corasick");
        System.out.println("- Similarity -> Set overlap / Jaccard; suffix-array code is also included in engine");
        System.out.println("- Graph algorithms / max-flow -> syllabus mapping only unless explicitly used by a feature");
        System.out.println("- NP-hard approximation, randomized algorithms, primality, parallel algorithms -> engine/reference topics, not all live search features");
        System.out.println("\nCO labels above are descriptive mappings. Replace them with your faculty's exact CO numbers/titles if your course document specifies them.");
        System.out.println("Measured runtime is shown for each search on the current machine; it varies with corpus size, JVM warm-up, and system load.");
    }

    private static void statistics() {
        List<LegalDocument> docs = REPOSITORY.all();
        if (docs.isEmpty()) { System.out.println("No records available for analytics."); return; }
        Map<String, Integer> categories = new LinkedHashMap<>();
        Map<String, Integer> statuses = new LinkedHashMap<>();
        Map<String, Integer> years = new LinkedHashMap<>();
        for (LegalDocument d : docs) {
            categories.merge(blankAs(d.getCategory(), "Unspecified"), 1, Integer::sum);
            statuses.merge(blankAs(d.getStatus(), "Unspecified"), 1, Integer::sum);
            years.merge(String.valueOf(d.getYear()), 1, Integer::sum);
        }
        System.out.println("Analytics: " + docs.size() + " documents | searches this session: " + searches + " | added this session: " + added);
        System.out.println("Opening visual dashboard...");
        AnalyticsDashboard.show(docs, searches, added, categories, statuses, years);
    }

    private static String blankAs(String value, String fallback) {
        return value == null || value.isBlank() ? fallback : value;
    }

    private static void aiAgentHub() throws IOException {
        while (true) {
            banner("LEXFIND LOCAL AI AGENT HUB");
            System.out.println("These local agents use explainable heuristics and your corpus; no API key or internet is required.");
            System.out.println("1. Legal Research Agent (rank documents for a question)");
            System.out.println("2. Document Summary Agent");
            System.out.println("3. Case Classification Agent");
            System.out.println("4. Legal Drafting Assistant (save new fictional record)");
            System.out.println("5. Data Quality Agent");
            System.out.println("6. Case Link / Citation Discovery Agent");
            System.out.println("7. Back to main menu");
            switch (ask("Select agent")) {
                case "1" -> researchAgent();
                case "2" -> summaryAgent();
                case "3" -> classificationAgent();
                case "4" -> draftingAgent();
                case "5" -> qualityAgent();
                case "6" -> citationAgent();
                case "7" -> { return; }
                default -> System.out.println("Choose 1-7.");
            }
        }
    }

    private static void researchAgent() throws IOException {
        String query = ask("Describe the legal topic or enter search terms").toLowerCase();
        if (query.isBlank()) { System.out.println("Question cannot be empty."); return; }
        String[] terms = query.split("[^a-z0-9]+");
        List<LegalDocument> ranked = new ArrayList<>(REPOSITORY.all());
        Map<String, Integer> scores = new HashMap<>();
        for (LegalDocument d : ranked) {
            String text = d.searchableText();
            int score = 0;
            for (String term : terms) if (term.length() > 1) {
                if (text.contains(term)) score += 2;
                if (d.getTitle().toLowerCase().contains(term)) score += 3;
                if (d.getKeywords().toLowerCase().contains(term)) score += 2;
            }
            scores.put(d.getDocumentId(), score);
        }
        ranked.removeIf(d -> scores.getOrDefault(d.getDocumentId(), 0) == 0);
        ranked.sort(Comparator.comparingInt((LegalDocument d) -> scores.get(d.getDocumentId())).reversed());
        System.out.println("\nRESEARCH AGENT RESULTS (heuristic relevance; verify source records)");
        if (ranked.isEmpty()) { System.out.println("No related documents found. Try different terms."); return; }
        for (int i = 0; i < Math.min(5, ranked.size()); i++) {
            LegalDocument d = ranked.get(i);
            System.out.printf("%d. [%s] %s | relevance score: %d | category: %s | status: %s%n",
                    i + 1, d.getDocumentId(), d.getTitle(), scores.get(d.getDocumentId()), d.getCategory(), d.getStatus());
            System.out.println("   Why surfaced: matching terms in title, keywords, metadata, or document text.");
        }
    }

    private static void summaryAgent() throws IOException {
        String id = ask("Document ID to summarize");
        LegalDocument d = REPOSITORY.findById(id);
        if (d == null) { System.out.println("Document not found."); return; }
        String content = d.getContent().replaceAll("(?m)^.*?:\\s*.*$", " ").replaceAll("\\s+", " ").trim();
        String[] sentences = content.split("(?<=[.!?])\\s+");
        System.out.println("\nSUMMARY AGENT | " + d.getDocumentId() + " - " + d.getTitle());
        System.out.println("Category: " + d.getCategory() + " | Status: " + d.getStatus());
        int printed = 0;
        for (String sentence : sentences) {
            String clean = sentence.trim();
            if (clean.length() < 25 || clean.toLowerCase().startsWith("case details")) continue;
            System.out.println("• " + (clean.length() > 260 ? clean.substring(0, 257) + "..." : clean));
            if (++printed == 3) break;
        }
        if (printed == 0) System.out.println("No narrative text could be extracted; use View Document Details for the complete record.");
        System.out.println("Note: extractive summary; it does not determine legal outcomes.");
    }

    private static void classificationAgent() throws IOException {
        String text = ask("Enter case title, facts, or keywords to classify").toLowerCase();
        if (text.isBlank()) { System.out.println("Input cannot be empty."); return; }
        Map<String, String[]> rules = new LinkedHashMap<>();
        rules.put("Cybercrime", new String[]{"cyber", "phishing", "malware", "hacking", "online fraud", "data breach"});
        rules.put("Property / Civil", new String[]{"property", "land", "ownership", "tenant", "boundary", "deed"});
        rules.put("Criminal", new String[]{"theft", "assault", "murder", "robbery", "fraud", "criminal"});
        rules.put("Family", new String[]{"divorce", "custody", "marriage", "maintenance", "family"});
        rules.put("Consumer", new String[]{"consumer", "defective product", "refund", "warranty", "service complaint"});
        rules.put("Employment", new String[]{"employment", "salary", "workplace", "termination", "wage"});
        rules.put("Contract", new String[]{"contract", "agreement", "breach", "supplier", "obligation"});
        String best = "General / Needs Review"; int bestScore = 0;
        for (Map.Entry<String, String[]> entry : rules.entrySet()) {
            int score = 0;
            for (String term : entry.getValue()) if (text.contains(term)) score++;
            if (score > bestScore) { best = entry.getKey(); bestScore = score; }
        }
        int confidence = bestScore == 0 ? 0 : Math.min(95, 55 + bestScore * 12);
        System.out.println("Suggested category: " + best);
        System.out.println("Rule matches: " + bestScore + " | heuristic confidence indicator: " + confidence + "%");
        System.out.println("Human review required; this is a category suggestion, not a legal determination.");
    }

    private static void draftingAgent() throws IOException {
        System.out.println("\nLEGAL DOCUMENT DRAFTING ASSISTANT");
        System.out.println("Creates an educational fictional draft. Not legal advice or a court-ready filing.");
        String id = ask("New Document ID (letters/numbers/_/- only)");
        if (!id.matches("[A-Za-z0-9_-]+") || REPOSITORY.findById(id) != null) {
            System.out.println("Invalid or duplicate ID. Existing records were not changed."); return;
        }
        String caseNo = ask("Case number");
        String title = ask("Document title");
        String category = ask("Category (Civil/Criminal/Family/Consumer/etc.)");
        String type = ask("Document type (Notice/Case Summary/Complaint/etc.)");
        String plaintiff = ask("Plaintiff / Applicant");
        String defendant = ask("Defendant / Respondent");
        String court = ask("Court / authority");
        String status = ask("Status (Draft/Pending/Under Review)");
        String facts = ask("Facts / background");
        String issue = ask("Main issue");
        String evidence = ask("Evidence / supporting material");
        String relief = ask("Requested action / relief");
        String keywords = ask("Keywords (comma-separated)");
        if (caseNo.isBlank() || title.isBlank() || category.isBlank() || type.isBlank()
                || facts.isBlank() || issue.isBlank()) {
            System.out.println("Case number, title, category, document type, facts, and issue are required.");
            System.out.println("No file was saved; your existing records remain unchanged.");
            return;
        }
        String date = LocalDate.now().format(DateTimeFormatter.ofPattern("dd-MM-yyyy"));
        String time = java.time.LocalTime.now().format(DateTimeFormatter.ofPattern("hh:mm a"));
        String body = "EDUCATIONAL DRAFT - FICTIONAL EXAMPLE ONLY\n\n"
                + "1. BACKGROUND AND FACTS\n" + facts + "\n\n"
                + "2. ISSUE FOR CONSIDERATION\n" + issue + "\n\n"
                + "3. EVIDENCE / SUPPORTING MATERIAL\n" + evidence + "\n\n"
                + "4. REQUESTED ACTION\n" + relief + "\n\n"
                + "5. REVIEW NOTE\nThis draft requires verification by a qualified legal professional.\n";
        String preview = "Document ID: " + id + "\nCase Number: " + caseNo + "\nTitle: " + title
                + "\nRegistration Date: " + date + "\nRegistration Time: " + time
                + "\nCategory: " + category + "\nYear: " + LocalDate.now().getYear()
                + "\nPlaintiff Name: " + plaintiff + "\nDefendant Name: " + defendant
                + "\nDocument Type: " + type + "\nCourt Name: " + court + "\nCase Status: " + status
                + "\nKeywords: " + keywords + "\n\nCase Details:\n" + body;
        System.out.println("\n--- DRAFT PREVIEW ---\n" + preview);
        if (!ask("Save this draft to the corpus? (yes/no)").equalsIgnoreCase("yes")) {
            System.out.println("Draft discarded; no files were changed."); return;
        }
        LegalDocument d = new LegalDocument(id, caseNo, title, date, time,
                category, LocalDate.now().getYear(), plaintiff, defendant, type,
                court, status, keywords, body);
        if (REPOSITORY.addAndSave(d)) {
            added++;
            System.out.println("Saved successfully. The new record is searchable now and after restarting LEXFIND.");
        } else System.out.println("Could not save: duplicate ID or file already exists.");
    }

    private static void qualityAgent() {
        List<LegalDocument> docs = REPOSITORY.all();
        int missingTitle = 0, missingCaseNo = 0, missingParties = 0, duplicateCaseNo = 0;
        Map<String, Integer> caseNos = new HashMap<>();
        for (LegalDocument d : docs) {
            if (d.getTitle().isBlank() || d.getTitle().equalsIgnoreCase("Untitled Legal Document")) missingTitle++;
            if (d.getCaseNumber().isBlank()) missingCaseNo++;
            if (d.getPlaintiff().isBlank() || d.getDefendant().isBlank()) missingParties++;
            caseNos.merge(d.getCaseNumber().toLowerCase(), 1, Integer::sum);
        }
        for (int count : caseNos.values()) if (count > 1) duplicateCaseNo += count - 1;
        banner("DATA QUALITY AGENT REPORT");
        System.out.println("Records checked: " + docs.size());
        System.out.println("Missing / generic titles: " + missingTitle);
        System.out.println("Missing case numbers: " + missingCaseNo);
        System.out.println("Missing plaintiff or defendant: " + missingParties);
        System.out.println("Repeated case numbers: " + duplicateCaseNo);
        System.out.println("The agent reports possible issues only; it does not auto-edit your source records.");
    }

    private static void citationAgent() {
        List<LegalDocument> docs = REPOSITORY.all();
        int links = 0;
        banner("CASE LINK DISCOVERY AGENT");
        for (LegalDocument source : docs) {
            String text = source.getContent().toLowerCase();
            List<String> matches = new ArrayList<>();
            for (LegalDocument target : docs) {
                if (source == target) continue;
                if (text.contains(target.getDocumentId().toLowerCase())
                        || (!target.getCaseNumber().isBlank() && text.contains(target.getCaseNumber().toLowerCase()))) {
                    matches.add(target.getDocumentId() + " (" + target.getTitle() + ")");
                }
            }
            if (!matches.isEmpty()) {
                links += matches.size();
                System.out.println(source.getDocumentId() + " may reference: " + String.join("; ", matches));
            }
        }
        if (links == 0) System.out.println("No explicit cross-record IDs/case numbers found in the current corpus.");
        System.out.println("Potential links detected: " + links + ". Text matches are suggestions, not verified legal citations.");
    }

    private static void projectAbout() {
        banner("LEXFIND | EXPO QUICK GUIDE");
        System.out.println("Problem: searching and navigating a collection of fictional legal records.");
        System.out.println("Core features: exact search, fuzzy fallback, multi-keyword search, similarity, details, repository browser.");
        System.out.println("DSA-3: KMP, Z, Rabin-Karp, Aho-Corasick, edit distance, suffix array/LCP, DP, flow, approximation, randomized and parallel algorithms.");
        System.out.println("Searches scan the text and metadata loaded from the local .txt corpus files.");
        System.out.println("Search reports include the measured runtime for the current machine.");
        System.out.println("Expo demo sequence: exact search -> typo/fuzzy search -> multi-keyword results table -> compare selected documents -> document summary/full view -> analytics.");
        System.out.println("Similarity percentages show unique-word overlap; they are not legal accuracy scores.");
        System.out.println("Corpus: fictional educational examples. Not real legal advice or official court records.");
    }

    private static List<LegalDocument> filterByType(List<LegalDocument> docs, String type) {
        if (type == null || type.isBlank() || type.equalsIgnoreCase("ALL")) return docs;
        String filter = type.toLowerCase().trim();
        List<LegalDocument> result = new ArrayList<>();
        for (LegalDocument d : docs) {
            if (d.getDocumentType().toLowerCase().contains(filter)
                    || d.getCategory().toLowerCase().contains(filter)
                    || d.getTitle().toLowerCase().contains(filter)) result.add(d);
        }
        return result;
    }

    private static int parsePositiveOrDefault(String text, int fallback) {
        try { int n = Integer.parseInt(text.trim()); return n > 0 ? n : fallback; }
        catch (Exception ex) { return fallback; }
    }

    private static String clip(String text, int max) {
        if (text == null) return "";
        String clean = text.replaceAll("\\s+", " ").trim();
        clean = clean.replaceAll("[^\\x00-\\x7F]", " ");
        return clean.length() <= max ? clean : clean.substring(0, Math.max(0, max - 3)) + "...";
    }

    private static Set<String> tokenSet(String text) {
        Set<String> result = new java.util.HashSet<>();
        for (String w : words(text)) if (w.length() > 2) result.add(w);
        return result;
    }

    private static int compareDocumentIds(String a, String b) {
        try {
            String na = a.replaceAll("\\D+", ""), nb = b.replaceAll("\\D+", "");
            int compared = Integer.compare(Integer.parseInt(na), Integer.parseInt(nb));
            return compared != 0 ? compared : a.compareToIgnoreCase(b);
        } catch (Exception ex) { return a.compareToIgnoreCase(b); }
    }

    private static final class SearchRow {
        final LegalDocument document; final int count; final String field; final String preview;
        SearchRow(LegalDocument d, int count, String field, String preview) {
            this.document = d; this.count = count; this.field = field; this.preview = preview;
        }
    }
    private static final class FuzzyRow {
        final LegalDocument document; final String word; final int distance;
        FuzzyRow(LegalDocument d, String word, int distance) { this.document = d; this.word = word; this.distance = distance; }
    }
    private static final class KeywordRow {
        final LegalDocument document; final List<String> keywords; final int total;
        KeywordRow(LegalDocument d, List<String> keywords, int total) { this.document = d; this.keywords = keywords; this.total = total; }
    }
    private static final class SimilarityRow {
        final LegalDocument document; final double score; final int shared; final int union;
        SimilarityRow(LegalDocument d, double score, int shared, int union) {
            this.document = d; this.score = score; this.shared = shared; this.union = union;
        }
    }

    private static String ask(String label) throws IOException { System.out.print(label + ": "); String value = IN.readLine(); return value == null ? "" : value.trim(); }
    private static String[] splitComma(String line) {
        if (line == null || line.isBlank()) return new String[0];
        return java.util.Arrays.stream(line.split(","))
                .map(String::trim).filter(value -> !value.isEmpty())
                .map(String::toLowerCase).toArray(String[]::new);
    }
    private static String[] words(String text) {
        return text.toLowerCase().split("[^a-z0-9]+");
    }
}
