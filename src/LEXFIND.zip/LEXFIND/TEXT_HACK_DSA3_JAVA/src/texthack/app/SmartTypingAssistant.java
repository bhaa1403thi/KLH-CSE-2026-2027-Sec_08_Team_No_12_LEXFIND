package texthack.app;

import java.awt.BorderLayout;
import java.awt.FlowLayout;
import java.awt.GraphicsEnvironment;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Locale;
import java.util.Set;
import java.util.TreeSet;
import java.util.concurrent.atomic.AtomicReference;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import javax.swing.BorderFactory;
import javax.swing.DefaultListModel;
import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JLabel;
import javax.swing.JList;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextField;
import javax.swing.ListSelectionModel;
import javax.swing.SwingUtilities;
import javax.swing.event.DocumentEvent;
import javax.swing.event.DocumentListener;
import texthack.model.LegalDocument;

/** Offline autocomplete built from the local legal-document corpus. */
public final class SmartTypingAssistant {
    private static final Pattern TOKEN = Pattern.compile("[a-zA-Z][a-zA-Z0-9'-]{2,}");
    private SmartTypingAssistant() {}

    public static String askForQuery(List<LegalDocument> documents, java.io.BufferedReader consoleInput) throws java.io.IOException {
        if (GraphicsEnvironment.isHeadless()) {
            System.out.println("Live typing suggestions need a desktop window. Enter your search below.");
            System.out.print("Search query: ");
            String line = consoleInput.readLine();
            return line == null ? "" : line.trim();
        }
        AtomicReference<String> result = new AtomicReference<>("");
        Runnable show = () -> result.set(showDialog(documents));
        try {
            if (SwingUtilities.isEventDispatchThread()) show.run();
            else SwingUtilities.invokeAndWait(show);
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(null, "Could not open typing assistant: " + ex.getMessage());
        }
        return result.get() == null ? "" : result.get().trim();
    }

    private static String showDialog(List<LegalDocument> documents) {
        List<String> vocabulary = buildVocabulary(documents);
        JDialog dialog = new JDialog((java.awt.Frame) null, "LEXFIND - Smart Typing Assistant", true);
        dialog.setDefaultCloseOperation(JDialog.DISPOSE_ON_CLOSE);
        dialog.setSize(610, 430);
        dialog.setLocationRelativeTo(null);
        JPanel root = new JPanel(new BorderLayout(10, 10));
        root.setBorder(BorderFactory.createEmptyBorder(16, 16, 14, 16));
        JLabel heading = new JLabel("Type a legal word or phrase");
        heading.setFont(heading.getFont().deriveFont(java.awt.Font.BOLD, 18f));
        JTextField input = new JTextField();
        input.setFont(input.getFont().deriveFont(16f));
        JLabel hint = new JLabel("Suggestions come from the local corpus. No internet or API is used.");
        DefaultListModel<String> model = new DefaultListModel<>();
        JList<String> list = new JList<>(model);
        list.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        list.setVisibleRowCount(9);
        JScrollPane scroll = new JScrollPane(list);
        JPanel center = new JPanel(new BorderLayout(0, 7));
        center.add(input, BorderLayout.NORTH);
        center.add(scroll, BorderLayout.CENTER);
        JPanel buttons = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        JButton useSuggestion = new JButton("Use Selected Suggestion");
        JButton search = new JButton("Search");
        JButton cancel = new JButton("Cancel");
        buttons.add(useSuggestion); buttons.add(search); buttons.add(cancel);
        root.add(heading, BorderLayout.NORTH);
        root.add(center, BorderLayout.CENTER);
        JPanel south = new JPanel(new BorderLayout(0, 8));
        south.add(hint, BorderLayout.NORTH); south.add(buttons, BorderLayout.SOUTH);
        root.add(south, BorderLayout.SOUTH);
        dialog.setContentPane(root);

        Runnable refresh = () -> {
            String q = input.getText().toLowerCase(Locale.ROOT).trim();
            model.clear();
            if (q.isEmpty()) {
                for (int i = 0; i < Math.min(8, vocabulary.size()); i++) model.addElement(vocabulary.get(i));
                return;
            }
            List<String> matches = new ArrayList<>();
            for (String phrase : vocabulary) if (phrase.startsWith(q)) matches.add(phrase);
            for (String phrase : vocabulary) if (!phrase.startsWith(q) && phrase.contains(q)) matches.add(phrase);
            for (int i = 0; i < Math.min(12, matches.size()); i++) model.addElement(matches.get(i));
            if (!model.isEmpty()) list.setSelectedIndex(0);
        };
        input.getDocument().addDocumentListener(new DocumentListener() {
            public void insertUpdate(DocumentEvent e) { refresh.run(); }
            public void removeUpdate(DocumentEvent e) { refresh.run(); }
            public void changedUpdate(DocumentEvent e) { refresh.run(); }
        });
        Runnable fillSelected = () -> { if (list.getSelectedValue() != null) input.setText(list.getSelectedValue()); input.requestFocusInWindow(); };
        AtomicReference<String> chosen = new AtomicReference<>("");
        useSuggestion.addActionListener(e -> fillSelected.run());
        list.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent e) { if (e.getClickCount() == 2 && list.getSelectedValue() != null) { input.setText(list.getSelectedValue()); chosen.set(input.getText()); dialog.dispose(); } }
        });
        list.addKeyListener(new KeyAdapter() { public void keyPressed(KeyEvent e) { if (e.getKeyCode() == KeyEvent.VK_ENTER && list.getSelectedValue() != null) { input.setText(list.getSelectedValue()); chosen.set(input.getText()); dialog.dispose(); } } });
        search.addActionListener(e -> { chosen.set(input.getText().trim()); dialog.dispose(); });
        cancel.addActionListener(e -> { chosen.set(""); dialog.dispose(); });
        input.addActionListener(e -> { chosen.set(input.getText().trim()); dialog.dispose(); });
        refresh.run();
        dialog.setVisible(true);
        return chosen.get();
    }

    private static List<String> buildVocabulary(List<LegalDocument> documents) {
        Set<String> phrases = new LinkedHashSet<>();
        for (LegalDocument d : documents) {
            addText(phrases, d.getTitle());
            addText(phrases, d.getCategory());
            addText(phrases, d.getKeywords());
            // Titles and keywords provide useful local two-word suggestions.
            addBigrams(phrases, d.getTitle());
            addBigrams(phrases, d.getKeywords());
        }
        String[] common = {"property dispute", "contract breach", "consumer complaint", "employment dispute",
                "family dispute", "criminal case", "cybercrime investigation", "copyright infringement",
                "land ownership", "fraud allegation", "evidence review", "court order", "case status"};
        for (String phrase : common) phrases.add(phrase);
        List<String> result = new ArrayList<>(phrases);
        result.sort(Comparator.comparingInt(String::length).thenComparing(String::compareTo));
        return result;
    }
    private static void addText(Set<String> phrases, String text) {
        if (text == null) return;
        Matcher matcher = TOKEN.matcher(text.toLowerCase(Locale.ROOT));
        while (matcher.find()) phrases.add(matcher.group());
    }
    private static void addBigrams(Set<String> phrases, String text) {
        if (text == null) return;
        Matcher matcher = TOKEN.matcher(text.toLowerCase(Locale.ROOT));
        String previous = null;
        while (matcher.find()) {
            String current = matcher.group();
            if (previous != null) phrases.add(previous + " " + current);
            previous = current;
        }
    }
}
