package texthack.engine.corpus;

import java.io.File;
import java.io.IOException;
import texthack.engine.stringalg.StringAlgorithms;

public class Corpus {
    public static class Document {
        public final String name;
        public final String text;
        public Document(String name,String text){this.name=name;this.text=text;}
    }

    private final File folder;
    public Corpus(String path){folder=new File(path);}

    public Document[] load() throws IOException {
        File[] files=folder.listFiles();
        if(files==null)return new Document[0];
        int count=0;for(File f:files)if(f.isFile()&&f.getName().endsWith(".txt"))count++;
        Document[] docs=new Document[count];int i=0;
        for(File f:files)if(f.isFile()&&f.getName().endsWith(".txt"))
            docs[i++]=new Document(f.getName(),StringAlgorithms.readFile(f));
        sortByName(docs);return docs;
    }

    private void sortByName(Document[] a){
        for(int i=1;i<a.length;i++){Document x=a[i];int j=i-1;while(j>=0&&a[j].name.compareTo(x.name)>0){a[j+1]=a[j];j--;}a[j+1]=x;}
    }
}
