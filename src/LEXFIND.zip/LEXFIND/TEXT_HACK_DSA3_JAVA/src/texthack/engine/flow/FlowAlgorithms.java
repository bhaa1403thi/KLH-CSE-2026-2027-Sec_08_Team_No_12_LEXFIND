package texthack.engine.flow;

import java.util.Arrays;

public final class FlowAlgorithms {
    private FlowAlgorithms(){}

    private static class Edge {
        int to, rev, cap;
        Edge(int t,int r,int c){to=t;rev=r;cap=c;}
    }

    private static Edge[][] makeGraph(int n,int[][] edges){
        int[] deg=new int[n];
        for(int[] e:edges){
            deg[e[0]]++;
            deg[e[1]]++;
        }

        Edge[][] g=new Edge[n][];
        for(int i=0;i<n;i++)g[i]=new Edge[deg[i]];

        int[] p=new int[n];
        for(int[] e:edges){
            int u=e[0],v=e[1],c=e[2];
            Edge a=new Edge(v,p[v],c);
            Edge b=new Edge(u,p[u],0);
            g[u][p[u]++]=a;
            g[v][p[v]++]=b;
            a.rev = p[v]-1;
            b.rev = p[u]-1;
        }
        return g;
    }

    public static int dinic(int n,int[][] edges,int s,int t){
        Edge[][] g=makeGraph(n,edges);int flow=0;int[] level=new int[n];
        while(bfs(g,s,t,level)){
            int[] it=new int[n];int f;
            while((f=dfs(g,s,t,1_000_000_000,it,level))>0)flow+=f;
        }
        return flow;
    }

    private static boolean bfs(Edge[][] g,int s,int t,int[] level){
        for(int i=0;i<level.length;i++)level[i]=-1;int[] q=new int[level.length];int h=0,tt=0;
        q[tt++]=s;level[s]=0;
        while(h<tt){int v=q[h++];for(Edge e:g[v])if(e.cap>0&&level[e.to]<0){level[e.to]=level[v]+1;q[tt++]=e.to;}}
        return level[t]>=0;
    }

    private static int dfs(Edge[][] g,int v,int t,int pushed,int[] it,int[] level){
        if(v==t)return pushed;
        while(it[v]<g[v].length){
            Edge e=g[v][it[v]];
            if(e.cap>0&&level[e.to]==level[v]+1){
                int f=dfs(g,e.to,t,Math.min(pushed,e.cap),it,level);
                if(f>0){e.cap-=f;g[e.to][e.rev].cap+=f;return f;}
            }
            it[v]++;
        }
        return 0;
    }

    public static int edmondsKarp(int n,int[][] input,int s,int t){
        int[][] cap=new int[n][n];
        for(int[] e:input){cap[e[0]][e[1]]+=e[2];}
        int total=0;
        while(true){
            int[] par=new int[n];for(int i=0;i<n;i++)par[i]=-1;par[s]=s;
            int[] q=new int[n];int h=0,tt=0;q[tt++]=s;
            while(h<tt&&par[t]==-1){int v=q[h++];for(int u=0;u<n;u++)if(par[u]==-1&&cap[v][u]>0){par[u]=v;q[tt++]=u;}}
            if(par[t]==-1)break;
            int f=Integer.MAX_VALUE;
            for(int v=t;v!=s;v=par[v])f=Math.min(f,cap[par[v]][v]);
            for(int v=t;v!=s;v=par[v]){cap[par[v]][v]-=f;cap[v][par[v]]+=f;}total+=f;
        }
        return total;
    }

    public static int fordFulkerson(int n,int[][] input,int s,int t){
        int[][] cap=new int[n][n];for(int[] e:input)cap[e[0]][e[1]]+=e[2];
        int total=0;
        while(true){
            boolean[] seen=new boolean[n];int[] path=new int[n];for(int i=0;i<n;i++)path[i]=-1;
            int f=dfsFF(cap,s,t,Integer.MAX_VALUE,seen,path);if(f==0)break;
            for(int v=t;v!=s;v=path[v]){cap[path[v]][v]-=f;cap[v][path[v]]+=f;}total+=f;
        }return total;
    }

    private static int dfsFF(int[][] cap,int v,int t,int f,boolean[] seen,int[] path){
        if(v==t)return f;seen[v]=true;
        for(int u=0;u<cap.length;u++)if(!seen[u]&&cap[v][u]>0){path[u]=v;int got=dfsFF(cap,u,t,Math.min(f,cap[v][u]),seen,path);if(got>0)return got;}
        return 0;
    }

    public static int[][] bipartiteMatching(int left,int right,int[][] pairs){
        int n=left+right+2,s=left+right,t=s+1;int[][] edges=new int[left+right+2+pairs.length*2][3];int c=0;
        for(int i=0;i<left;i++)edges[c++]=new int[]{s,i,1};
        for(int j=0;j<right;j++)edges[c++]=new int[]{left+j,t,1};
        for(int[] p:pairs)edges[c++]=new int[]{p[0],left+p[1],1};
        int[][] use=Arrays.copyOf(edges,c);
        int flow=dinic(n,use,s,t);
        return new int[][]{{flow}};
    }

    public static int projectSelectionValue(int[] profit,int[] cost,int[][] dependencies){
        int n=profit.length,s=n,t=n+1,positive=0;int[][] e=new int[n*n+2][3];int c=0;
        for(int i=0;i<n;i++){
            if(profit[i]>=0){e[c++]=new int[]{s,i,profit[i]};positive+=profit[i];}
            else e[c++]=new int[]{i,t,-profit[i]};
        }
        for(int[] d:dependencies)e[c++]=new int[]{d[0],d[1],1_000_000};
        int[][] use=Arrays.copyOf(e,c);
        return positive-dinic(n+2,use,s,t);
    }
}
