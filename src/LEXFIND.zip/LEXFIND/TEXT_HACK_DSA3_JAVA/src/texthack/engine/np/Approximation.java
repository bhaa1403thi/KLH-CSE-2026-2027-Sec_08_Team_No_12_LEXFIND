package texthack.engine.np;

public final class Approximation {
    private Approximation(){}

    // Greedy 2-approximation for Vertex Cover.
    public static boolean[] vertexCover2Approx(int n,int[][] edges){
        boolean[] chosen=new boolean[n],covered=new boolean[edges.length];
        for(int i=0;i<edges.length;i++)if(!covered[i]){
            int u=edges[i][0],v=edges[i][1];chosen[u]=true;chosen[v]=true;
            for(int j=i;j<edges.length;j++)if((edges[j][0]==u||edges[j][1]==u||edges[j][0]==v||edges[j][1]==v))covered[j]=true;
        }
        return chosen;
    }

    // Greedy set cover. universe elements are 0..universeSize-1.
    public static int[] greedySetCover(int universeSize,int[][] sets){
        boolean[] covered=new boolean[universeSize];boolean[] used=new boolean[sets.length];
        int[] result=new int[sets.length];int count=0,total=0;
        while(total<universeSize){
            int best=-1,bestGain=0;
            for(int i=0;i<sets.length;i++)if(!used[i]){
                int gain=0;for(int x:sets[i])if(!covered[x])gain++;
                if(gain>bestGain){bestGain=gain;best=i;}
            }
            if(best==-1)break;
            used[best]=true;result[count++]=best;
            for(int x:sets[best])if(!covered[x]){covered[x]=true;total++;}
        }
        int[] out=new int[count];for(int i=0;i<count;i++)out[i]=result[i];return out;
    }

    public static int subsetSum(int[] a,int target){
        boolean[] dp=new boolean[target+1];dp[0]=true;
        for(int x:a)for(int s=target;s>=x;s--)if(dp[s-x])dp[s]=true;
        return dp[target]?1:0;
    }

    public static int knapsack01(int[] value,int[] weight,int capacity){
        int[] dp=new int[capacity+1];
        for(int i=0;i<value.length;i++)for(int c=capacity;c>=weight[i];c--)
            dp[c]=Math.max(dp[c],dp[c-weight[i]]+value[i]);
        return dp[capacity];
    }
}
