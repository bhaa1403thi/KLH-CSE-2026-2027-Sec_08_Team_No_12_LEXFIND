package texthack.engine.dp;

public final class AdvancedDP {
    private AdvancedDP() {}

    public static int levenshtein(String a, String b) {
        int n=a.length(), m=b.length();
        int[] prev=new int[m+1], cur=new int[m+1];
        for(int j=0;j<=m;j++) prev[j]=j;
        for(int i=1;i<=n;i++){
            cur[0]=i;
            for(int j=1;j<=m;j++){
                int cost=a.charAt(i-1)==b.charAt(j-1)?0:1;
                cur[j]=Math.min(Math.min(cur[j-1]+1,prev[j]+1),prev[j-1]+cost);
            }
            int[] t=prev;prev=cur;cur=t;
        }
        return prev[m];
    }

    public static int damerauLevenshtein(String a, String b) {
        int n=a.length(),m=b.length();
        int[][] d=new int[n+2][m+2]; int INF=n+m;
        d[0][0]=INF;
        for(int i=0;i<=n;i++){d[i+1][1]=i;d[i+1][0]=INF;}
        for(int j=0;j<=m;j++){d[1][j+1]=j;d[0][j+1]=INF;}
        int[] last=new int[256];
        for(int i=1;i<=n;i++){
            int db=0;
            for(int j=1;j<=m;j++){
                int i1=last[b.charAt(j-1)%256], j1=db;
                int cost=a.charAt(i-1)==b.charAt(j-1)?0:1;
                if(cost==0) db=j;
                d[i+1][j+1]=Math.min(Math.min(d[i][j]+cost,d[i+1][j]+1),
                    Math.min(d[i][j+1]+1,d[i1][j1]+(i-i1-1)+1+(j-j1-1)));
            }
            last[a.charAt(i-1)%256]=i;
        }
        return d[n+1][m+1];
    }

    public static int weightedEditDistance(String a,String b,int insert,int delete,int replace){
        int n=a.length(),m=b.length(); int[] p=new int[m+1],c=new int[m+1];
        for(int j=0;j<=m;j++)p[j]=j*insert;
        for(int i=1;i<=n;i++){
            c[0]=i*delete;
            for(int j=1;j<=m;j++){
                int r=p[j-1]+(a.charAt(i-1)==b.charAt(j-1)?0:replace);
                c[j]=Math.min(Math.min(c[j-1]+insert,p[j]+delete),r);
            }
            int[] t=p;p=c;c=t;
        }
        return p[m];
    }

    public static int needlemanWunsch(String a,String b,int match,int mismatch,int gap){
        int n=a.length(),m=b.length();int[][] d=new int[n+1][m+1];
        for(int i=1;i<=n;i++)d[i][0]=d[i-1][0]+gap;
        for(int j=1;j<=m;j++)d[0][j]=d[0][j-1]+gap;
        for(int i=1;i<=n;i++)for(int j=1;j<=m;j++){
            int diag=d[i-1][j-1]+(a.charAt(i-1)==b.charAt(j-1)?match:mismatch);
            d[i][j]=Math.max(diag,Math.max(d[i-1][j]+gap,d[i][j-1]+gap));
        }
        return d[n][m];
    }

    public static int smithWaterman(String a,String b,int match,int mismatch,int gap){
        int n=a.length(),m=b.length(),best=0;int[][] d=new int[n+1][m+1];
        for(int i=1;i<=n;i++)for(int j=1;j<=m;j++){
            int diag=d[i-1][j-1]+(a.charAt(i-1)==b.charAt(j-1)?match:mismatch);
            d[i][j]=Math.max(0,Math.max(diag,Math.max(d[i-1][j]+gap,d[i][j-1]+gap)));
            if(d[i][j]>best)best=d[i][j];
        }
        return best;
    }

    public static long matrixChain(int[] p){
        int n=p.length-1; long[][] d=new long[n+1][n+1];
        for(int len=2;len<=n;len++)for(int i=1;i+len-1<=n;i++){
            int j=i+len-1;d[i][j]=Long.MAX_VALUE/4;
            for(int k=i;k<j;k++){
                long q=d[i][k]+d[k+1][j]+(long)p[i-1]*p[k]*p[j];
                if(q<d[i][j])d[i][j]=q;
            }
        }
        return d[1][n];
    }

    public static long tspBitmask(int[][] w){
        int n=w.length,states=1<<n; long INF=Long.MAX_VALUE/4;
        long[][] dp=new long[states][n];
        for(int s=0;s<states;s++)for(int i=0;i<n;i++)dp[s][i]=INF;
        dp[1][0]=0;
        for(int mask=1;mask<states;mask++)for(int u=0;u<n;u++)if(dp[mask][u]<INF){
            for(int v=0;v<n;v++)if((mask&(1<<v))==0){
                long q=dp[mask][u]+w[u][v]; if(q<dp[mask|1<<v][v])dp[mask|1<<v][v]=q;
            }
        }
        long best=INF;int full=states-1;
        for(int u=1;u<n;u++)best=Math.min(best,dp[full][u]+w[u][0]);
        return best;
    }

    public static boolean hamiltonianPath(int[][] g){
        int n=g.length,states=1<<n; boolean[][] dp=new boolean[states][n];
        for(int i=0;i<n;i++)dp[1<<i][i]=true;
        for(int mask=0;mask<states;mask++)for(int v=0;v<n;v++)if(dp[mask][v])
            for(int u=0;u<n;u++)if(g[v][u]!=0&&(mask&(1<<u))==0)dp[mask|1<<u][u]=true;
        for(int v=0;v<n;v++)if(dp[states-1][v])return true;return false;
    }

    public static int[] sosSum(int[] f,int bits){
        int[] a=new int[f.length];for(int i=0;i<f.length;i++)a[i]=f[i];
        for(int b=0;b<bits;b++)for(int mask=0;mask<a.length;mask++)
            if((mask&(1<<b))!=0)a[mask]+=a[mask^(1<<b)];
        return a;
    }

    public static int treeSubsetMax(int[] weight,int[][] edges){
        int n=weight.length;int[] parent=new int[n];for(int i=0;i<n;i++)parent[i]=-2;parent[0]=-1;
        int[] order=new int[n],q=new int[n];int h=0,t=0;q[t++]=0;
        int[][] adj=buildAdj(n,edges);
        while(h<t){int v=q[h++];order[h-1]=v;for(int i=0;i<adj[v].length;i++){int u=adj[v][i];if(parent[u]==-2){parent[u]=v;q[t++]=u;}}}
        int[] take=new int[n],skip=new int[n];
        for(int k=n-1;k>=0;k--){int v=order[k];take[v]=weight[v];for(int u:adj[v])if(parent[u]==v){take[v]+=skip[u];skip[v]+=Math.max(take[u],skip[u]);}}
        return Math.max(take[0],skip[0]);
    }

    private static int[][] buildAdj(int n,int[][] edges){
        int[] deg=new int[n];for(int[] e:edges){deg[e[0]]++;deg[e[1]]++;}
        int[][] a=new int[n][];for(int i=0;i<n;i++)a[i]=new int[deg[i]];
        int[] p=new int[n];for(int[] e:edges){a[e[0]][p[e[0]]++]=e[1];a[e[1]][p[e[1]]++]=e[0];}return a;
    }
}
