package texthack.engine.randomized;

public final class RandomizedAlgorithms {
    private RandomizedAlgorithms(){}

    public static boolean millerRabin(long n,int rounds,long seed){
        if(n<2)return false;
        int[] small={2,3,5,7,11,13,17,19,23,29,31,37};
        for(int p:small){if(n==p)return true;if(n%p==0)return false;}
        long d=n-1;int s=0;while((d&1)==0){d>>=1;s++;}
        long xseed=seed|1;
        for(int r=0;r<rounds;r++){
            xseed=xorshift(xseed);
            long a=2+floorMod(xseed,n-3);
            long x=powMod(a,d,n);
            if(x==1||x==n-1)continue;
            boolean witness=true;
            for(int i=1;i<s;i++){x=mulMod(x,x,n);if(x==n-1){witness=false;break;}}
            if(witness)return false;
        }
        return true;
    }

    private static long xorshift(long x){x^=x<<13;x^=x>>>7;x^=x<<17;return x;}
    private static long floorMod(long a,long b){long r=a%b;return r<0?r+b:r;}

    private static long mulMod(long a,long b,long mod){
        long result=0;a%=mod;
        while(b>0){if((b&1)!=0)result=(result+a)%mod;a=(a+a)%mod;b>>=1;}
        return result;
    }
    private static long powMod(long a,long e,long mod){
        long r=1;a%=mod;
        while(e>0){if((e&1)!=0)r=mulMod(r,a,mod);a=mulMod(a,a,mod);e>>=1;}
        return r;
    }

    public static void randomizedQuickSort(int[] a,long seed){
        quick(a,0,a.length-1,seed);
    }
    private static void quick(int[] a,int lo,int hi,long seed){
        if(lo>=hi)return;
        long s=xorshift(seed+(long)lo*0x9E3779B97F4A7C15L);
        int p=lo+(int)floorMod(s,hi-lo+1), pivot=a[p];
        int i=lo,j=hi;
        while(i<=j){while(a[i]<pivot)i++;while(a[j]>pivot)j--;if(i<=j){int t=a[i];a[i]=a[j];a[j]=t;i++;j--;}}
        quick(a,lo,j,s);quick(a,i,hi,s^0xD1B54A32D192ED03L);
    }

    public static int[] reservoirSample(int[] stream,int k,long seed){
        int[] r=new int[Math.min(k,stream.length)];
        for(int i=0;i<r.length;i++)r[i]=stream[i];
        long s=seed;
        for(int i=k;i<stream.length;i++){
            s=xorshift(s);long j=floorMod(s,i+1);
            if(j<k)r[(int)j]=stream[i];
        }
        return r;
    }

    public static int universalHash(int key,int a,int b,int prime,int tableSize){
        long x=(long)a*key+b;long h=x%prime;if(h<0)h+=prime;return (int)(h%tableSize);
    }
}
