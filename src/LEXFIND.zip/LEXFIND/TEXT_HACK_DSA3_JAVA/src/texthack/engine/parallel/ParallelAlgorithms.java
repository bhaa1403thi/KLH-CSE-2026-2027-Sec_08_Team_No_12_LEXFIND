package texthack.engine.parallel;

public final class ParallelAlgorithms {
    private ParallelAlgorithms(){}

    public static long work(int[] a){long s=0;for(int x:a)s+=x;return s;}

    public static long parallelReduce(int[] a,int threads)throws InterruptedException{
        int p=Math.max(1,Math.min(threads,a.length));long[] partial=new long[p];Thread[] ts=new Thread[p];
        for(int t=0;t<p;t++){final int id=t,from=t*a.length/p,to=(t+1)*a.length/p;ts[t]=new Thread(()->{long s=0;for(int i=from;i<to;i++)s+=a[i];partial[id]=s;});ts[t].start();}
        for(Thread t:ts)t.join();long total=0;for(long x:partial)total+=x;return total;
    }

    public static int[] prefixScan(int[] a){
        int[] out=new int[a.length],temp=new int[a.length];
        if(a.length==0)return out;
        for(int i=0;i<a.length;i++)out[i]=a[i];
        for(int offset=1;offset<a.length;offset<<=1){
            for(int i=0;i<a.length;i++)temp[i]=out[i];
            for(int i=offset;i<a.length;i++)out[i]=temp[i]+temp[i-offset];
        }
        return out;
    }

    public static long brentUpperBound(long work,long span,int processors){
        if(processors<1)processors=1;
        return (work+processors-1)/processors+span;
    }
}
