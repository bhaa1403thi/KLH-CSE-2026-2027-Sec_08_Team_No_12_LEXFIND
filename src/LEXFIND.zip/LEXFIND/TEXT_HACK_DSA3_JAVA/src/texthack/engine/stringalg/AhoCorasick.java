package texthack.engine.stringalg;

public class AhoCorasick {
    private final String[] patterns;
    private static class Node {
        int[] next = new int[128];
        int fail;
        int output;
        int[] outputIds = new int[0];
        Node() {
            for (int i = 0; i < next.length; i++) next[i] = -1;
        }
    }

    private Node[] nodes = new Node[4096];
    private int size = 1;

    public AhoCorasick(String[] patterns) {
        this.patterns = patterns;
        nodes[0] = new Node();
        for (int i = 0; i < patterns.length; i++) insert(patterns[i], i);
        build();
    }

    private void insert(String s, int patternId) {
        int cur = 0;
        for (int i = 0; i < s.length(); i++) {
            char c = s.charAt(i);
            if (c >= 128) continue;
            if (nodes[cur].next[c] == -1) {
                if (size == nodes.length) grow();
                nodes[size] = new Node();
                nodes[cur].next[c] = size++;
            }
            cur = nodes[cur].next[c];
        }
        nodes[cur].output++;
        int[] ids = new int[nodes[cur].outputIds.length + 1];
        for (int i = 0; i < nodes[cur].outputIds.length; i++) ids[i] = nodes[cur].outputIds[i];
        ids[ids.length - 1] = patternId;
        nodes[cur].outputIds = ids;
    }

    private void grow() {
        Node[] x = new Node[nodes.length * 2];
        for (int i = 0; i < nodes.length; i++) x[i] = nodes[i];
        nodes = x;
    }

    private void build() {
        int[] q = new int[size + 1]; int head = 0, tail = 0;
        for (int c = 0; c < 128; c++) {
            int v = nodes[0].next[c];
            if (v != -1) { nodes[v].fail = 0; q[tail++] = v; }
            else nodes[0].next[c] = 0;
        }
        while (head < tail) {
            int v = q[head++];
            nodes[v].output += nodes[nodes[v].fail].output;
            nodes[v].outputIds = merge(nodes[v].outputIds, nodes[nodes[v].fail].outputIds);
            for (int c = 0; c < 128; c++) {
                int u = nodes[v].next[c];
                if (u != -1) {
                    nodes[u].fail = nodes[nodes[v].fail].next[c];
                    q[tail++] = u;
                } else {
                    nodes[v].next[c] = nodes[nodes[v].fail].next[c];
                }

            }
        }
    }

    private static int[] merge(int[] first, int[] second) {
        int[] result = new int[first.length + second.length];
        for (int i = 0; i < first.length; i++) result[i] = first[i];
        for (int i = 0; i < second.length; i++) result[first.length + i] = second[i];
        return result;
    }

    public int countMatches(String text) {
        int state = 0, count = 0;
        for (int i = 0; i < text.length(); i++) {
            char c = text.charAt(i);
            if (c >= 128) { state = 0; continue; }
            state = nodes[state].next[c];
            count += nodes[state].output;
        }
        return count;
    }

    public int[] matchingCounts(String text) {
        int[] counts = new int[patterns.length];
        int state = 0;
        for (int i = 0; i < text.length(); i++) {
            char c = Character.toLowerCase(text.charAt(i));
            if (c >= 128) { state = 0; continue; }
            state = nodes[state].next[c];
            for (int patternId : nodes[state].outputIds) counts[patternId]++;
        }
        return counts;
    }
}
