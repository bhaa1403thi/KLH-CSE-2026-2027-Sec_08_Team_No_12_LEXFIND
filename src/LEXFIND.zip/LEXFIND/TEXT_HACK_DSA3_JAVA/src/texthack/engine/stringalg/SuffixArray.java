package texthack.engine.stringalg;

public final class SuffixArray {
    private SuffixArray() {}

    public static int[] build(String s) {
        int n = s.length();
        int[] sa = new int[n];
        int[] rank = new int[n];
        int[] tmp = new int[n];
        for (int i = 0; i < n; i++) { sa[i] = i; rank[i] = s.charAt(i); }
        for (int k = 1; k < n; k *= 2) {
            sort(sa, rank, k);
            tmp[sa[0]] = 0;
            for (int i = 1; i < n; i++) {
                int a = sa[i-1], b = sa[i];
                boolean diff = rank[a] != rank[b] ||
                    (a+k < n ? rank[a+k] : -1) != (b+k < n ? rank[b+k] : -1);
                tmp[b] = tmp[a] + (diff ? 1 : 0);
            }
            for (int i = 0; i < n; i++) rank[i] = tmp[i];
            if (rank[sa[n-1]] == n-1) break;
        }
        return sa;
    }

    private static void sort(int[] sa, int[] rank, int k) {
        quickSort(sa, 0, sa.length - 1, rank, k);
    }

    private static int key(int idx, int[] rank, int k) {
        return idx + k < rank.length ? rank[idx + k] : -1;
    }

    private static boolean less(int a, int b, int[] rank, int k) {
        if (rank[a] != rank[b]) return rank[a] < rank[b];
        return key(a, rank, k) < key(b, rank, k);
    }

    private static void quickSort(int[] a, int lo, int hi, int[] rank, int k) {
        if (lo >= hi) return;
        int i = lo, j = hi, p = a[(lo+hi)>>>1];
        while (i <= j) {
            while (less(a[i], p, rank, k)) i++;
            while (less(p, a[j], rank, k)) j--;
            if (i <= j) { int t=a[i]; a[i]=a[j]; a[j]=t; i++; j--; }
        }
        if (lo < j) quickSort(a, lo, j, rank, k);
        if (i < hi) quickSort(a, i, hi, rank, k);
    }

    public static int[] kasaiLcp(String s, int[] sa) {
        int n = s.length();
        int[] rank = new int[n];
        int[] lcp = new int[n];
        for (int i = 0; i < n; i++) rank[sa[i]] = i;
        int h = 0;
        for (int i = 0; i < n; i++) {
            int r = rank[i];
            if (r == 0) continue;
            int j = sa[r-1];
            while (i+h<n && j+h<n && s.charAt(i+h)==s.charAt(j+h)) h++;
            lcp[r] = h;
            if (h > 0) h--;
        }
        return lcp;
    }

    public static int longestCommonSubstring(String a, String b) {
        String x = a + '\u0001' + b;
        int split = a.length();
        int[] sa = build(x);
        int[] lcp = kasaiLcp(x, sa);
        int best = 0;
        for (int i = 1; i < sa.length; i++) {
            boolean left = sa[i] < split;
            boolean right = sa[i] > split;
            boolean prevLeft = sa[i-1] < split;
            boolean prevRight = sa[i-1] > split;
            if ((left && prevRight) || (right && prevLeft)) {
                if (lcp[i] > best) best = lcp[i];
            }
        }
        return best;
    }
}
