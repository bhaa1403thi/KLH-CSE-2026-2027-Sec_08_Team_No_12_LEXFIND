package texthack.engine.stringalg;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;

public final class StringAlgorithms {
    private StringAlgorithms() {}

    public static int naiveSearch(String text, String pattern) {
        if (pattern.length() == 0) return 0;
        if (pattern.length() > text.length()) return -1;
        for (int i = 0; i <= text.length() - pattern.length(); i++) {
            int j = 0;
            while (j < pattern.length() && text.charAt(i + j) == pattern.charAt(j)) j++;
            if (j == pattern.length()) return i;
        }
        return -1;
    }

    public static int[] kmpAll(String text, String pattern) {
        int[] empty = new int[0];
        if (pattern.length() == 0) return empty;
        int[] lps = buildLps(pattern);
        int[] temp = new int[text.length() + 1];
        int count = 0, i = 0, j = 0;
        while (i < text.length()) {
            if (text.charAt(i) == pattern.charAt(j)) {
                i++; j++;
                if (j == pattern.length()) {
                    temp[count++] = i - j;
                    j = lps[j - 1];
                }
            } else if (j > 0) {
                j = lps[j - 1];
            } else {
                i++;
            }
        }
        int[] ans = new int[count];
        for (int k = 0; k < count; k++) ans[k] = temp[k];
        return ans;
    }

    public static int[] buildLps(String pattern) {
        int[] lps = new int[pattern.length()];
        int len = 0, i = 1;
        while (i < pattern.length()) {
            if (pattern.charAt(i) == pattern.charAt(len)) lps[i++] = ++len;
            else if (len > 0) len = lps[len - 1];
            else lps[i++] = 0;
        }
        return lps;
    }

    public static int[] zFunction(String s) {
        int n = s.length();
        int[] z = new int[n];
        int l = 0, r = 0;
        for (int i = 1; i < n; i++) {
            if (i <= r) z[i] = Math.min(r - i + 1, z[i - l]);
            while (i + z[i] < n && s.charAt(z[i]) == s.charAt(i + z[i])) z[i]++;
            if (i + z[i] - 1 > r) { l = i; r = i + z[i] - 1; }
        }
        return z;
    }

    public static int[] zSearch(String text, String pattern) {
        if (pattern.length() == 0) return new int[0];
        String combined = pattern + '\u0000' + text;
        int[] z = zFunction(combined);
        int[] temp = new int[text.length() + 1];
        int count = 0, offset = pattern.length() + 1;
        for (int i = offset; i < combined.length(); i++) {
            if (z[i] >= pattern.length()) temp[count++] = i - offset;
        }
        int[] ans = new int[count];
        for (int i = 0; i < count; i++) ans[i] = temp[i];
        return ans;
    }

    public static int[] rabinKarp(String text, String pattern) {
        if (pattern.length() == 0) return new int[0];
        if (pattern.length() > text.length()) return new int[0];
        final long mod1 = 1000000007L, mod2 = 1000000009L, base = 911382323L;
        int m = pattern.length(), n = text.length();
        long p1 = 1, p2 = 1, ph1 = 0, ph2 = 0, th1 = 0, th2 = 0;
        for (int i = 0; i < m; i++) {
            ph1 = (ph1 * base + pattern.charAt(i)) % mod1;
            ph2 = (ph2 * base + pattern.charAt(i)) % mod2;
            th1 = (th1 * base + text.charAt(i)) % mod1;
            th2 = (th2 * base + text.charAt(i)) % mod2;
            if (i < m - 1) { p1 = p1 * base % mod1; p2 = p2 * base % mod2; }
        }
        int[] temp = new int[n + 1]; int count = 0;
        for (int i = 0; i <= n - m; i++) {
            if (ph1 == th1 && ph2 == th2 && text.regionMatches(i, pattern, 0, m)) temp[count++] = i;
            if (i < n - m) {
                th1 = ((th1 - text.charAt(i) * p1) % mod1 + mod1) % mod1;
                th1 = (th1 * base + text.charAt(i + m)) % mod1;
                th2 = ((th2 - text.charAt(i) * p2) % mod2 + mod2) % mod2;
                th2 = (th2 * base + text.charAt(i + m)) % mod2;
            }
        }
        int[] ans = new int[count];
        for (int i = 0; i < count; i++) ans[i] = temp[i];
        return ans;
    }

    public static String readFile(File file) throws IOException {
        StringBuilder b = new StringBuilder();
        BufferedReader r = new BufferedReader(new FileReader(file, java.nio.charset.StandardCharsets.UTF_8));
        String line;
        while ((line = r.readLine()) != null) b.append(line).append('\n');
        r.close();
        return b.toString();
    }
}
