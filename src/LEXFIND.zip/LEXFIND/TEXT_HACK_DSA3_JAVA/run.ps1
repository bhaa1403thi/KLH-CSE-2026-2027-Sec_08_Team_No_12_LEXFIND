$ErrorActionPreference = 'Stop'
Set-Location $PSScriptRoot
if (-not (Test-Path 'out')) { New-Item -ItemType Directory -Path 'out' | Out-Null }
$javaFiles = Get-ChildItem -Recurse src -Filter *.java | ForEach-Object { $_.FullName }
if (-not $javaFiles) { throw 'No Java source files were found under src.' }
javac -encoding UTF-8 -d out $javaFiles
if ($LASTEXITCODE -ne 0) { throw 'Compilation failed. Check the JDK installation and compiler output.' }
java -cp out texthack.app.TextHackApp
