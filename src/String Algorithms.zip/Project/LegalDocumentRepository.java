import java.io.*;
import java.util.*;

public class LegalDocumentRepository {

    // ============================================================
    // CONFIGURATION
    // ============================================================

    static final String FOLDER = "documents";
    static final int TOTAL_DOCUMENTS = 5;

    // ============================================================
    // DOCUMENT CLASS
    // ============================================================

    static class Document {

        String id;
        String caseNumber;
        String title;
        String registrationDate;
        String registrationTime;
        String category;
        String year;

        String victimName;
        String victimAge;
        String victimPhone;

        String opponentName;
        String opponentPhone;

        String witnessName;
        String lawyerName;
        String judgeName;

        String courtName;
        String location;
        String caseStatus;

        String details;

        Document(
                String id,
                String caseNumber,
                String title,
                String registrationDate,
                String registrationTime,
                String category,
                String year,
                String victimName,
                String victimAge,
                String victimPhone,
                String opponentName,
                String opponentPhone,
                String witnessName,
                String lawyerName,
                String judgeName,
                String courtName,
                String location,
                String caseStatus,
                String details) {

            this.id = id;
            this.caseNumber = caseNumber;
            this.title = title;
            this.registrationDate = registrationDate;
            this.registrationTime = registrationTime;
            this.category = category;
            this.year = year;

            this.victimName = victimName;
            this.victimAge = victimAge;
            this.victimPhone = victimPhone;

            this.opponentName = opponentName;
            this.opponentPhone = opponentPhone;

            this.witnessName = witnessName;
            this.lawyerName = lawyerName;
            this.judgeName = judgeName;

            this.courtName = courtName;
            this.location = location;
            this.caseStatus = caseStatus;

            this.details = details;
        }
    }

    // ============================================================
    // FILE HANDLING
    // ============================================================

    static String readFile(String fileName) {

        StringBuilder content = new StringBuilder();

        try {

            BufferedReader reader =
                    new BufferedReader(new FileReader(fileName));

            String line;

            while ((line = reader.readLine()) != null) {

                content.append(line).append("\n");
            }

            reader.close();

        } catch (IOException e) {

            System.out.println(
                    "Error reading file: " + fileName
            );
        }

        return content.toString();
    }

    // ============================================================
    // GET FIELD FROM DOCUMENT
    // ============================================================

    static String getField(String content, String field) {

        String[] lines = content.split("\n");

        for (String line : lines) {

            line = line.trim();

            if (line.startsWith(field)) {

                return line.substring(field.length()).trim();
            }
        }

        return "Not Available";
    }

    // ============================================================
    // GET CASE DETAILS
    // ============================================================

    static String getDetails(String content) {

        String[] lines = content.split("\n");

        StringBuilder details =
                new StringBuilder();

        boolean start = false;

        for (String line : lines) {

            if (line.trim().equals("Case Details:")) {

                start = true;
                continue;
            }

            if (start) {

                details.append(line).append(" ");
            }
        }

        return details.toString().trim();
    }

    // ============================================================
    // LOAD DOCUMENT
    // ============================================================

    static Document loadDocument(String fileName) {

        String content = readFile(fileName);

        if (content.isEmpty()) {

            return null;
        }

        return new Document(

                getField(content, "Document ID:"),
                getField(content, "Case Number:"),
                getField(content, "Title:"),
                getField(content, "Registration Date:"),
                getField(content, "Registration Time:"),
                getField(content, "Category:"),
                getField(content, "Year:"),

                getField(content, "Victim Name:"),
                getField(content, "Victim Age:"),
                getField(content, "Victim Phone:"),

                getField(content, "Opponent Name:"),
                getField(content, "Opponent Phone:"),

                getField(content, "Witness Name:"),
                getField(content, "Lawyer Name:"),
                getField(content, "Judge Name:"),

                getField(content, "Court Name:"),
                getField(content, "Location:"),
                getField(content, "Case Status:"),

                getDetails(content)
        );
    }

    // ============================================================
    // KMP PATTERN MATCHING
    // ============================================================

    static void computeLPS(
            String pattern,
            int[] lps) {

        int length = 0;

        int i = 1;

        lps[0] = 0;

        while (i < pattern.length()) {

            if (pattern.charAt(i)
                    == pattern.charAt(length)) {

                length++;

                lps[i] = length;

                i++;

            } else {

                if (length != 0) {

                    length =
                            lps[length - 1];

                } else {

                    lps[i] = 0;

                    i++;
                }
            }
        }
    }

    // ============================================================
    // KMP SEARCH
    // Returns number of occurrences
    // ============================================================

    static int kmpSearch(
            String text,
            String pattern) {

        text = text.toLowerCase();

        pattern = pattern.toLowerCase();

        if (pattern.length() == 0) {

            return 0;
        }

        int n = text.length();

        int m = pattern.length();

        int[] lps = new int[m];

        computeLPS(pattern, lps);

        int i = 0;

        int j = 0;

        int count = 0;

        while (i < n) {

            if (text.charAt(i)
                    == pattern.charAt(j)) {

                i++;

                j++;
            }

            if (j == m) {

                count++;

                j = lps[j - 1];

            } else if (
                    i < n &&
                    text.charAt(i)
                            != pattern.charAt(j)) {

                if (j != 0) {

                    j = lps[j - 1];

                } else {

                    i++;
                }
            }
        }

        return count;
    }

    // ============================================================
    // LEVENSHTEIN EDIT DISTANCE
    // DYNAMIC PROGRAMMING
    // ============================================================

    static int editDistance(
            String a,
            String b) {

        a = a.toLowerCase();

        b = b.toLowerCase();

        int n = a.length();

        int m = b.length();

        int[][] dp =
                new int[n + 1][m + 1];

        // Empty second string
        for (int i = 0; i <= n; i++) {

            dp[i][0] = i;
        }

        // Empty first string
        for (int j = 0; j <= m; j++) {

            dp[0][j] = j;
        }

        for (int i = 1; i <= n; i++) {

            for (int j = 1; j <= m; j++) {

                if (a.charAt(i - 1)
                        == b.charAt(j - 1)) {

                    dp[i][j] =
                            dp[i - 1][j - 1];

                } else {

                    int insert =
                            dp[i][j - 1];

                    int delete =
                            dp[i - 1][j];

                    int replace =
                            dp[i - 1][j - 1];

                    dp[i][j] =
                            1 + Math.min(
                                    insert,
                                    Math.min(
                                            delete,
                                            replace
                                    )
                            );
                }
            }
        }

        return dp[n][m];
    }

    // ============================================================
    // GET WORDS FROM DOCUMENTS
    // ============================================================

    static ArrayList<String> getAllWords() {

        ArrayList<String> words =
                new ArrayList<>();

        for (int i = 1;
             i <= TOTAL_DOCUMENTS;
             i++) {

            String fileName =
                    FOLDER + "/d" + i + ".txt";

            String content =
                    readFile(fileName);

            String cleaned =
                    content
                            .toLowerCase()
                            .replaceAll(
                                    "[^a-zA-Z ]",
                                    " "
                            );

            String[] documentWords =
                    cleaned.split("\\s+");

            for (String word :
                    documentWords) {

                if (word.length() >= 3
                        && !words.contains(word)) {

                    words.add(word);
                }
            }
        }

        return words;
    }

    // ============================================================
    // FUZZY SEARCH
    // ============================================================

    static ArrayList<String> getSuggestions(
            String keyword) {

        ArrayList<String> words =
                getAllWords();

        ArrayList<String> suggestions =
                new ArrayList<>();

        int minimumDistance =
                Integer.MAX_VALUE;

        // Find minimum distance
        for (String word : words) {

            int distance =
                    editDistance(
                            keyword,
                            word
                    );

            if (distance <
                    minimumDistance) {

                minimumDistance =
                        distance;
            }
        }

        // Add words having minimum
        // or near-minimum distance
        for (String word : words) {

            int distance =
                    editDistance(
                            keyword,
                            word
                    );

            if (distance <=
                    minimumDistance + 1
                    &&
                    distance <= 3) {

                if (!suggestions.contains(
                        word)) {

                    suggestions.add(word);
                }
            }
        }

        return suggestions;
    }

    // ============================================================
    // PATTERN SEARCH
    // ============================================================

    static void patternSearch(
            String keyword) {

        int totalDocuments = 0;

        int totalMatches = 0;

        System.out.println();

        System.out.println(
                "========================================================"
        );

        System.out.println(
                "                  PATTERN SEARCH"
        );

        System.out.println(
                "========================================================"
        );

        System.out.println();

        System.out.println(
                "Keyword: " + keyword
        );

        System.out.println();

        System.out.println(
                "Searching using KMP String Matching Algorithm..."
        );

        System.out.println();

        System.out.println(
                "--------------------------------------------------------"
        );

        System.out.println(
                "                    SEARCH RESULTS"
        );

        System.out.println(
                "--------------------------------------------------------"
        );

        System.out.println();

        for (int i = 1;
             i <= TOTAL_DOCUMENTS;
             i++) {

            String fileName =
                    FOLDER + "/d" + i + ".txt";

            String content =
                    readFile(fileName);

            int occurrences =
                    kmpSearch(
                            content,
                            keyword
                    );

            if (occurrences > 0) {

                Document doc =
                        loadDocument(
                                fileName
                        );

                totalDocuments++;

                totalMatches +=
                        occurrences;

                System.out.println(
                        "Document ID     : "
                                + doc.id
                );

                System.out.println(
                        "Case Number     : "
                                + doc.caseNumber
                );

                System.out.println(
                        "Title           : "
                                + doc.title
                );

                System.out.println(
                        "Category        : "
                                + doc.category
                );

                System.out.println(
                        "Registration    : "
                                + doc.registrationDate
                                + ", "
                                + doc.registrationTime
                );

                System.out.println(
                        "Judge           : "
                                + doc.judgeName
                );

                System.out.println(
                        "Lawyer          : "
                                + doc.lawyerName
                );

                System.out.println(
                        "Occurrences     : "
                                + occurrences
                );

                System.out.println();
            }
        }

        System.out.println(
                "--------------------------------------------------------"
        );

        if (totalDocuments == 0) {

            System.out.println(
                    "Exact match not found."
            );

            fuzzySearch(keyword);

        } else {

            System.out.println(
                    "Total Documents Found : "
                            + totalDocuments
            );

            System.out.println(
                    "Total Matches          : "
                            + totalMatches
            );

            System.out.println(
                    "--------------------------------------------------------"
            );

            System.out.println(
                    "Algorithm Used         : KMP"
            );

            System.out.println(
                    "Time Complexity        : O(n + m)"
            );

            System.out.println(
                    "--------------------------------------------------------"
            );
        }
    }

    // ============================================================
    // FUZZY SEARCH
    // ============================================================

    static void fuzzySearch(
            String keyword) {

        System.out.println();

        System.out.println(
                "Using Levenshtein Edit Distance..."
        );

        ArrayList<String> suggestions =
                getSuggestions(keyword);

        if (suggestions.isEmpty()) {

            System.out.println();

            System.out.println(
                    "No similar keyword found."
            );

            return;
        }

        System.out.println();

        System.out.println(
                "Did you mean:"
        );

        int number = 1;

        for (String suggestion :
                suggestions) {

            int distance =
                    editDistance(
                            keyword,
                            suggestion
                    );

            System.out.println(
                    number
                            + ". "
                            + suggestion
                            + "    Edit Distance: "
                            + distance
            );

            number++;

            if (number > 5) {
                break;
            }
        }

        System.out.println();

        Scanner scanner =
                new Scanner(System.in);

        System.out.print(
                "Enter suggested keyword "
                        + "to search, or press Enter to cancel: "
        );

        String selected =
                scanner.nextLine();

        if (!selected.trim().isEmpty()) {

            patternSearch(selected);
        }
    }

    // ============================================================
    // CREATE SET OF WORDS
    // ============================================================

    static HashSet<String> createWordSet(
            String text) {

        HashSet<String> set =
                new HashSet<>();

        String cleaned =
                text
                        .toLowerCase()
                        .replaceAll(
                                "[^a-zA-Z ]",
                                " "
                        );

        String[] words =
                cleaned.split("\\s+");

        for (String word : words) {

            if (word.length() > 2) {

                set.add(word);
            }
        }

        return set;
    }

    // ============================================================
    // JACCARD SIMILARITY
    // ============================================================

    static double jaccardSimilarity(
            String text1,
            String text2) {

        HashSet<String> set1 =
                createWordSet(text1);

        HashSet<String> set2 =
                createWordSet(text2);

        HashSet<String> intersection =
                new HashSet<>(set1);

        intersection.retainAll(set2);

        HashSet<String> union =
                new HashSet<>(set1);

        union.addAll(set2);

        if (union.size() == 0) {

            return 0.0;
        }

        return (
                (double) intersection.size()
                        / union.size()
        ) * 100.0;
    }

    // ============================================================
    // DOCUMENT SIMILARITY
    // ============================================================

    static void documentSimilarity(
            String documentId) {

        Document reference = null;

        String referenceContent = "";

        // Find reference document
        for (int i = 1;
             i <= TOTAL_DOCUMENTS;
             i++) {

            String fileName =
                    FOLDER + "/d" + i + ".txt";

            Document doc =
                    loadDocument(fileName);

            if (doc != null &&
                    doc.id.equalsIgnoreCase(
                            documentId)) {

                reference = doc;

                referenceContent =
                        readFile(fileName);

                break;
            }
        }

        if (reference == null) {

            System.out.println();

            System.out.println(
                    "Document not found."
            );

            return;
        }

        System.out.println();

        System.out.println(
                "========================================================"
        );

        System.out.println(
                "              DOCUMENT SIMILARITY"
        );

        System.out.println(
                "========================================================"
        );

        System.out.println();

        System.out.println(
                "Reference Document : "
                        + reference.id
        );

        System.out.println(
                "Title              : "
                        + reference.title
        );

        System.out.println();

        System.out.println(
                "Comparing with other legal documents..."
        );

        System.out.println();

        System.out.println(
                "--------------------------------------------------------"
        );

        System.out.println(
                "                 SIMILAR DOCUMENTS"
        );

        System.out.println(
                "--------------------------------------------------------"
        );

        double highestSimilarity =
                -1;

        String mostSimilarId =
                "";

        String mostSimilarTitle =
                "";

        for (int i = 1;
             i <= TOTAL_DOCUMENTS;
             i++) {

            String fileName =
                    FOLDER + "/d" + i + ".txt";

            Document doc =
                    loadDocument(fileName);

            if (doc == null) {
                continue;
            }

            if (doc.id.equalsIgnoreCase(
                    documentId)) {

                continue;
            }

            String content =
                    readFile(fileName);

            double similarity =
                    jaccardSimilarity(
                            referenceContent,
                            content
                    );

            System.out.println();

            System.out.println(
                    "Document ID : "
                            + doc.id
            );

            System.out.println(
                    "Title       : "
                            + doc.title
            );

            System.out.printf(
                    "Similarity  : %.2f%%%n",
                    similarity
            );

            if (similarity >
                    highestSimilarity) {

                highestSimilarity =
                        similarity;

                mostSimilarId =
                        doc.id;

                mostSimilarTitle =
                        doc.title;
            }
        }

        System.out.println();

        System.out.println(
                "--------------------------------------------------------"
        );

        System.out.println(
                "Most Similar Document : "
                        + mostSimilarId
        );

        System.out.println(
                "Title                 : "
                        + mostSimilarTitle
        );

        System.out.printf(
                "Similarity            : %.2f%%%n",
                highestSimilarity
        );

        System.out.println();

        System.out.println(
                "Algorithm Used        : Jaccard Similarity"
        );

        System.out.println(
                "--------------------------------------------------------"
        );
    }

    // ============================================================
    // VIEW ALL DOCUMENTS
    // ============================================================

    static void viewAllDocuments() {

        System.out.println();

        System.out.println(
                "========================================================"
        );

        System.out.println(
                "                  ALL DOCUMENTS"
        );

        System.out.println(
                "========================================================"
        );

        for (int i = 1;
             i <= TOTAL_DOCUMENTS;
             i++) {

            String fileName =
                    FOLDER + "/d" + i + ".txt";

            Document doc =
                    loadDocument(fileName);

            if (doc != null) {

                System.out.println();

                System.out.println(
                        "Document ID     : "
                                + doc.id
                );

                System.out.println(
                        "Case Number     : "
                                + doc.caseNumber
                );

                System.out.println(
                        "Title           : "
                                + doc.title
                );

                System.out.println(
                        "Category        : "
                                + doc.category
                );

                System.out.println(
                        "Registration    : "
                                + doc.registrationDate
                                + " "
                                + doc.registrationTime
                );

                System.out.println(
                        "Case Status     : "
                                + doc.caseStatus
                );

                System.out.println(
                        "--------------------------------------------------------"
                );
            }
        }
    }

    // ============================================================
    // VIEW COMPLETE CASE DETAILS
    // ============================================================

    static void viewCaseDetails(
            String documentId) {

        boolean found = false;

        for (int i = 1;
             i <= TOTAL_DOCUMENTS;
             i++) {

            String fileName =
                    FOLDER + "/d" + i + ".txt";

            Document doc =
                    loadDocument(fileName);

            if (doc != null &&
                    doc.id.equalsIgnoreCase(
                            documentId)) {

                found = true;

                System.out.println();

                System.out.println(
                        "========================================================"
                );

                System.out.println(
                        "                  CASE DETAILS"
                );

                System.out.println(
                        "========================================================"
                );

                System.out.println();

                System.out.println(
                        "Document ID       : "
                                + doc.id
                );

                System.out.println(
                        "Case Number       : "
                                + doc.caseNumber
                );

                System.out.println(
                        "Title             : "
                                + doc.title
                );

                System.out.println();

                System.out.println(
                        "--------------------------------------------------------"
                );

                System.out.println(
                        "REGISTRATION DETAILS"
                );

                System.out.println(
                        "--------------------------------------------------------"
                );

                System.out.println(
                        "Registration Date : "
                                + doc.registrationDate
                );

                System.out.println(
                        "Registration Time : "
                                + doc.registrationTime
                );

                System.out.println(
                        "Year              : "
                                + doc.year
                );

                System.out.println(
                        "Category          : "
                                + doc.category
                );

                System.out.println(
                        "Court             : "
                                + doc.courtName
                );

                System.out.println(
                        "Location          : "
                                + doc.location
                );

                System.out.println();

                System.out.println(
                        "--------------------------------------------------------"
                );

                System.out.println(
                        "PARTIES"
                );

                System.out.println(
                        "--------------------------------------------------------"
                );

                System.out.println(
                        "Victim Name       : "
                                + doc.victimName
                );

                System.out.println(
                        "Victim Age        : "
                                + doc.victimAge
                );

                System.out.println(
                        "Victim Phone      : "
                                + doc.victimPhone
                );

                System.out.println();

                System.out.println(
                        "Opponent Name     : "
                                + doc.opponentName
                );

                System.out.println(
                        "Opponent Phone    : "
                                + doc.opponentPhone
                );

                System.out.println();

                System.out.println(
                        "--------------------------------------------------------"
                );

                System.out.println(
                        "LEGAL TEAM"
                );

                System.out.println(
                        "--------------------------------------------------------"
                );

                System.out.println(
                        "Lawyer Name       : "
                                + doc.lawyerName
                );

                System.out.println(
                        "Judge Name        : "
                                + doc.judgeName
                );

                System.out.println();

                System.out.println(
                        "--------------------------------------------------------"
                );

                System.out.println(
                        "WITNESS"
                );

                System.out.println(
                        "--------------------------------------------------------"
                );

                System.out.println(
                        "Witness Name      : "
                                + doc.witnessName
                );

                System.out.println();

                System.out.println(
                        "--------------------------------------------------------"
                );

                System.out.println(
                        "CASE STATUS"
                );

                System.out.println(
                        "--------------------------------------------------------"
                );

                System.out.println(
                        "Status            : "
                                + doc.caseStatus
                );

                System.out.println();

                System.out.println(
                        "--------------------------------------------------------"
                );

                System.out.println(
                        "CASE DETAILS"
                );

                System.out.println(
                        "--------------------------------------------------------"
                );

                System.out.println(
                        doc.details
                );

                System.out.println();

                System.out.println(
                        "========================================================"
                );

                break;
            }
        }

        if (!found) {

            System.out.println();

            System.out.println(
                    "Document with ID "
                            + documentId
                            + " not found."
            );
        }
    }

    // ============================================================
    // MAIN
    // ============================================================

    public static void main(
            String[] args) {

        Scanner scanner =
                new Scanner(System.in);

        int choice;

        do {

            System.out.println();

            System.out.println(
                    "========================================================"
            );

            System.out.println(
                    "             LEGAL DOCUMENT REPOSITORY"
            );

            System.out.println(
                    "========================================================"
            );

            System.out.println();

            System.out.println(
                    "1. View All Documents"
            );

            System.out.println(
                    "2. Pattern Search (KMP)"
            );

            System.out.println(
                    "3. Fuzzy Search (Edit Distance)"
            );

            System.out.println(
                    "4. Document Similarity (Jaccard)"
            );

            System.out.println(
                    "5. View Case Details"
            );

            System.out.println(
                    "6. Exit"
            );

            System.out.println();

            System.out.print(
                    "Enter your choice: "
            );

            choice =
                    scanner.nextInt();

            scanner.nextLine();

            switch (choice) {

                // ------------------------------------------------
                // VIEW ALL
                // ------------------------------------------------

                case 1:

                    viewAllDocuments();

                    break;

                // ------------------------------------------------
                // PATTERN MATCHING
                // ------------------------------------------------

                case 2:

                    System.out.print(
                            "\nEnter keyword: "
                    );

                    String keyword =
                            scanner.nextLine();

                    if (keyword.trim().isEmpty()) {

                        System.out.println(
                                "Keyword cannot be empty."
                        );

                    } else {

                        patternSearch(
                                keyword
                        );
                    }

                    break;

                // ------------------------------------------------
                // FUZZY SEARCH
                // ------------------------------------------------

                case 3:

                    System.out.print(
                            "\nEnter keyword: "
                    );

                    String fuzzyKeyword =
                            scanner.nextLine();

                    if (fuzzyKeyword.trim().isEmpty()) {

                        System.out.println(
                                "Keyword cannot be empty."
                        );

                    } else {

                        fuzzySearch(
                                fuzzyKeyword
                        );
                    }

                    break;

                // ------------------------------------------------
                // SIMILARITY
                // ------------------------------------------------

                case 4:

                    System.out.print(
                            "\nEnter Document ID: "
                    );

                    String documentId =
                            scanner.nextLine();

                    documentSimilarity(
                            documentId
                    );

                    break;

                // ------------------------------------------------
                // CASE DETAILS
                // ------------------------------------------------

                case 5:

                    System.out.print(
                            "\nEnter Document ID: "
                    );

                    String id =
                            scanner.nextLine();

                    viewCaseDetails(id);

                    break;

                // ------------------------------------------------
                // EXIT
                // ------------------------------------------------

                case 6:

                    System.out.println();

                    System.out.println(
                            "Thank you for using "
                                    + "Legal Document Repository."
                    );

                    break;

                default:

                    System.out.println();

                    System.out.println(
                            "Invalid choice. Please try again."
                    );
            }

        } while (choice != 6);

        scanner.close();
    }
}